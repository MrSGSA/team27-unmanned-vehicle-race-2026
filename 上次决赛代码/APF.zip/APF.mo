﻿model APF "人工势场法"
  extends ModelWorkspace;
  import SysplorerEmbeddedCoder.Types.*;
  import BaseWorkspace.*;
  annotation(__MWORKS(modelType=Control,PortArrangement,BlockSystem(blockKind=BlockKind.userModel,SampleTime(auto=true,group="")=0.02),CodeGeneration(Config = {"code_comments":{"blocks":false,"descriptions":false,"eliminated_objects":false,"enable":false,"nested_objects":false},"code_placement":{"mode":"Compact"},"code_replacement":{"fixed_point_library":"Fixed-TY","standard_c_library":"C99"},"custom_code":{"code":{"function_declare":{"head":"","item_head":"","item_tail":"","tail":"void Terminate();"},"function_define":{"head":"","item_head":"","item_tail":"","tail":""},"global_variable_declare":{"head":"","item_head":"","item_tail":"","tail":""},"global_variable_define":{"head":"","item_head":"","item_tail":"","tail":"void Terminate()\n{\n  fd = serialOpen(\"/dev/ttyAMA0\", 115200);\n  delayMicroseconds(20000);\n  void vehicle_speed(double, double);\n  vehicle_speed(0, 0);\n}"},"include":{"head":"","item_head":"","item_tail":"","tail":""},"macro":{"head":"","item_head":"","item_tail":"","tail":""},"type":{"head":"#include <wiringPi.h>\n#include <wiringSerial.h>\n#include <softPwm.h>\n#include <signal.h>\n#include <math.h>\n#include <stdlib.h>\n#include <unistd.h>\n\nextern int fd;","item_head":"","item_tail":"","tail":""}},"code_protection":{"integer_division_by_zero":false,"overflow":false}},"data_type":{"real_as_float":true},"experiment":{"task_and_sample":{"muti_task_mode":false}},"hardware_platform":{"byte_ordering":"大端序","largest_atomic_size":{"floating_point":"32","integer":"32"},"number_of_bits":{"char":8,"double":32,"float":32,"int":32,"long":32,"long_long":0,"pointer":32,"ptrdiff_t":32,"size_t":32},"support_dynamic_memory_allocation":false,"support_float_point":true,"target":"get","type_platform":"ARM Cortex-M0","vendor":"中颖科技"},"identifier":{"format":{"function":"{{model_name}}{{name}}","global_variable":"{{model_name}}{{data_type}}{{prefix}}{{name}}","local_variable":"{{data_type}}{{prefix}}{{name}}","macro":"{{model_name}}{{name}}","mem_var"
:"{{model_name}}{{name}}"
,"type":"{{model_name}}{{name}}"},"format_string":{"boolean":"b","input":"in","integer":"i","output":"out","parameter":"p","real":"r"},"max_length":32,"style":{"function":"camelCase","global_variable":"camelCase","local_variable":"camelCase","macro":"camelCase","mem_var":"camelCase","type":"camelCase"}},"interface":{"array_layout":"row_major","function_name":{"initialize":"Init","step":"Step","terminate":""},"generate_capi_for_param":false,"generate_capi_for_root_IO":false,"generate_capi_for_signal":false,"generate_capi_for_state":false,"have_terminate":false},"optimization":{"Code":"size","array_loop_threshold":5,"logical_operator":"logical"}}, Sim_seting = {"sim_seting":{"output":"F:/TR/Documents/MWorks"}})),Icon(coordinateSystem(extent={{-100,-100},{100,100}}, 
grid={2,2}),graphics = {Rectangle(origin={0,0}, 
fillColor={255,245,225}, 
fillPattern=FillPattern.Solid, 
extent={{-100,-100},{100,100}}), Rectangle(origin={0,7.10543e-15}, 
lineColor={0,0,0}, 
fillColor={179,179,179}, 
lineThickness=1, 
extent={{-60,60},{60,-60}}, 
radius=10), Rectangle(origin={0,0}, 
lineColor={0,0,0}, 
fillColor={179,179,179}, 
lineThickness=1, 
extent={{-45,45},{45,-45}}), Line(origin={-65.5437,-8}, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={-65.5437,24}, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={-65.5437,8}, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={-65.5437,40}, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={-65.5437,-24}, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={-65.5437,-40}, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={66.0833,-8}, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={66.0833,24}, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={66.0833,8}, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={66.0833,40}, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={66.0833,-24}, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={66.0833,-40}, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={8,65.4261}, 
rotation=90, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={-24,65.4261}, 
rotation=90, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={-8,65.4261}, 
rotation=90, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={-40,65.4261}, 
rotation=90, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={24,65.4261}, 
rotation=90, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={40,65.4261}, 
rotation=90, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={8,-65.9799}, 
rotation=90, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={-24,-65.9799}, 
rotation=90, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={-8,-65.9799}, 
rotation=90, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={-40,-65.9799}, 
rotation=90, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={24,-65.9799}, 
rotation=90, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Line(origin={40,-65.9799}, 
rotation=90, 
points={{-5,0},{5,0}}, 
thickness=1, 
smooth=Smooth.Bezier, 
__MWorks_Manhattanize=true), Text(origin={0,-120}, 
extent={{-150,20},{150,-20}}, 
textString="%name", 
fontSize=14, 
verticalAlignment=TextAlignment.Top)}),experiment(DoublePrecision=false,Algorithm=Euler,InlineIntegrator=false,InlineStepSize=false,Interval=-1,StartTime=0,StopTime=1,Tolerance=0.0001),Diagram(coordinateSystem(extent={{-100,-100},{100,100}}, 
grid={2,2}),graphics = {Rectangle(origin={-200,18.0418}, 
fillColor={255,255,255}, 
fillPattern=FillPattern.Solid, 
extent={{-57,86.0418},{57,-86.0418}}), Text(origin={-202,-32}, 
lineColor={0,0,0}, 
extent={{-35,10},{35,-10}}, 
textString="从树莓派获取5个超声波
距离传感器的模型", 
fontSize=18, 
textStyle={TextStyle.None}, 
textColor={0,0,0}), Text(origin={-202,-56}, 
lineColor={255,0,0}, 
extent={{-46,10},{46,-10}}, 
textString="参赛选手不需改动此模型", 
fontSize=22, 
fontName="黑体", 
textStyle={TextStyle.None}, 
textColor={255,0,0}), Rectangle(origin={-60.3333,18.0418}, 
fillColor={255,255,255}, 
fillPattern=FillPattern.Solid, 
extent={{-65.6667,86.0418},{65.6667,-86.0418}}), Text(origin={-59,-49.9999}, 
lineColor={0,85,255}, 
extent={{-48.6667,12.0001},{48.6667,-12.0001}}, 
textString="参赛选手小车控制模型
（基于初赛模型迭代）", 
fontSize=22, 
fontName="黑体", 
textStyle={TextStyle.None}, 
textColor={0,85,255}), Rectangle(origin={94,18.0418}, 
fillColor={255,255,255}, 
fillPattern=FillPattern.Solid, 
extent={{-65.6667,86.0418},{65.6667,-86.0418}}), Text(origin={96,-32}, 
lineColor={0,0,0}, 
extent={{-35,10},{35,-10}}, 
textString="将车速和差速等数据
发送给树莓派的模型", 
fontSize=18, 
textStyle={TextStyle.None}, 
textColor={0,0,0}), Text(origin={96,-55.9165}, 
lineColor={255,0,0}, 
extent={{-46,10},{46,-10}}, 
textString="参赛选手不需改动此模型", 
fontSize=22, 
fontName="黑体", 
textStyle={TextStyle.None}, 
textColor={255,0,0})}));
  SubSystem1 raspberry_SetMsg annotation(Placement(transformation(origin={109,40.1439}, 
extent={{-33,-29.6931},{33,29.6931}})),__MWORKS(ComponentNamePlacement(BOTTOM),PortLabels(labelType="SignalName",labels(label(text="u1",instance="u1"),label(text="u2",instance="u2"),label(text="u3",instance="u3"),label(text="u4",instance="u4"),label(text="u5",instance="u5")))));
  Raspberry_Pi_Interface.Raspberry_GetMsg raspberry_GetMsg1 
    annotation (Placement(transformation(origin={-200,39.91252}, 
extent={{-33,-35.4412},{33,35.4412}})),__MWORKS(SECInstance=true,ComponentNamePlacement(BOTTOM),BlockSystem(SampleTime(group="")=0)));
  SysplorerEmbeddedCoder.Sources.Constant constant1(k=0) 
    annotation (Placement(transformation(origin={-59,-18}, 
extent={{-10,-10},{10,10}})),__MWORKS(BlockSystem(SampleTime(auto=true,group="D1")=0.02,Instance(y(Type(ref="double") ,Dimension=1) ,k(Type(ref="double") ,Dimension=1)))));
  Controller.APF aPF 
    annotation (Placement(transformation(origin={-59,45.892}, 
extent={{-37,-35.4412},{37,35.4412}})),__MWORKS(SECInstance=true,ComponentNamePlacement(BOTTOM),BlockSystem(SampleTime(group="")=0)));
  model ModelWorkspace
    annotation(__MWORKS(hide = true,BlockSystem(blockKind=BlockKind.modelWorkspace)));
  end ModelWorkspace;
  block SubSystem1 "选择子系统模块的设置。 要启用涉及代码生成的相关参数, 请选择 '视为原子单元' 。"

    annotation (__MWORKS(PortArrangement(Left(speed, gap, steer, u4, u5)),BlockSystem(blockKind=BlockKind.subSystem, SampleTime(auto=true), SubSystem(virtual=true, functionPack=FunctionPack.auto, functionName="", sourceFile="")),independentInstance=true,hide=true,sourceModel=SysplorerEmbeddedCoder.SubSystems.SubSystem), Icon(coordinateSystem(extent={{-300, -120}, {300, 120}}, grid={2, 2}), graphics={Rectangle(origin = {0, 0}, fillColor = {255, 255, 255}, fillPattern = FillPattern.Solid, lineThickness = 1, extent = {{-300, 120}, {300, -120}}), Text(origin = {6.217248937900877e-15, -142}, lineColor = {0, 0, 0}, extent = {{0, 20}, {0, -20}}, textString = "%name", fontSize = 14, textStyle = {TextStyle.None}, textColor = {0, 0, 0}, verticalAlignment = TextAlignment.Top)}),Protection(access=Access.packageDuplicate));
    block CCaller2

        annotation(
         __MWORKS(PortArrangement(Left(speed,gap), Right()),BlockSystem(blockKind = BlockKind.atomic,bltBlockKind = BltBlockKind.ccaller,SampleTime=-1),independentInstance = true,sourceModel = SysplorerEmbeddedCoder.Utilities.CCaller,ExternalFunctionBlock,hide = true), 
              Icon(coordinateSystem(extent = { {-200.0, -100.0}, {200.0, 100.0} }, 
              preserveAspectRatio = false, 
              initialScale = 0.1, 
              grid = { 2.0, 2.0 }), graphics = { Rectangle(origin = {0.0, 0.0}, 
              fillColor = {255, 255, 255}, 
              fillPattern = FillPattern.Solid, 
              extent = {{-200.0, 100.0}, {200.0, -100.0}}), Text(origin = {0.0, 0.0}, 
              extent = {{-200.0, 20.0}, {200, -20}}, 
              textString = "vehicle_speed", 
              verticalAlignment = TextAlignment.VCenter), Text(origin = {0.0, -120.0}, 
              lineColor = {0, 0, 0}, 
              extent = {{-150, 20}, {150, -20}}, 
              textString = "%name", 
              fontSize = 14, 
             textStyle = {TextStyle.None}, 
              textColor = {0, 0, 0}, 
              verticalAlignment = TextAlignment.Top) }), 
          Diagram(coordinateSystem(extent = { {-100.0, -100.0}, {100.0, 100.0} }, 
              preserveAspectRatio = false, 
              initialScale = 0.1, 
              grid = { 2.0, 2.0 })));
      function func_CCaller2
      input SysplorerEmbeddedCoder.Types.Auto speed annotation(__MWORKS(BlockSystem(Type(inherit = InheritType.none, ref="double"), Dimension(dimensionType = DimensionType.none) = 1)));
      input SysplorerEmbeddedCoder.Types.Auto gap annotation(__MWORKS(BlockSystem(Type(inherit = InheritType.none, ref="double"), Dimension(dimensionType = DimensionType.none) = 1)));
    external "C" vehicle_speed(speed,gap);
    end func_CCaller2;
        SysplorerEmbeddedCoder.Port.Inport speed 
        annotation(__MWORKS(BlockSystem(Type(inherit = InheritType.none, ref = "double"),Dimension(dimensionType = DimensionType.none) = 1)), Placement(transformation(origin = {0,0}, extent = { {-10,-10}, {10,10} })));
        SysplorerEmbeddedCoder.Port.Inport gap 
        annotation(__MWORKS(BlockSystem(Type(inherit = InheritType.none, ref = "double"),Dimension(dimensionType = DimensionType.none) = 1)), Placement(transformation(origin = {0,0}, extent = { {-10,-10}, {10,10} })));
      equation

      func_CCaller2(speed, gap);
    end CCaller2;
    block CCaller

        annotation(
         __MWORKS(PortArrangement(Left(), Right()),BlockSystem(blockKind = BlockKind.atomic,bltBlockKind = BltBlockKind.ccaller,SampleTime=-1),independentInstance = true,sourceModel = SysplorerEmbeddedCoder.Utilities.CCaller,ExternalFunctionBlock,hide = true), 
              Icon(coordinateSystem(extent = { {-200.0, -100.0}, {200.0, 100.0} }, 
              preserveAspectRatio = false, 
              initialScale = 0.1, 
              grid = { 2.0, 2.0 }), graphics = { Rectangle(origin = {0.0, 0.0}, 
              fillColor = {255, 255, 255}, 
              fillPattern = FillPattern.Solid, 
              extent = {{-200.0, 100.0}, {200.0, -100.0}}), Text(origin = {0.0, 0.0}, 
              extent = {{-200.0, 20.0}, {200, -20}}, 
              textString = "rasInit", 
              verticalAlignment = TextAlignment.VCenter), Text(origin = {0.0, -120.0}, 
              lineColor = {0, 0, 0}, 
              extent = {{-150, 20}, {150, -20}}, 
              textString = "%name", 
              fontSize = 14, 
             textStyle = {TextStyle.None}, 
              textColor = {0, 0, 0}, 
              verticalAlignment = TextAlignment.Top) }), 
          Diagram(coordinateSystem(extent = { {-100.0, -100.0}, {100.0, 100.0} }, 
              preserveAspectRatio = false, 
              initialScale = 0.1, 
              grid = { 2.0, 2.0 })));
      function func_CCaller
    external "C" rasInit() 
    annotation (Include = "#include <wiringPi.h>
#include <wiringSerial.h>
#include <softPwm.h>
#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <signal.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>

#define Trig1 4     // 传感器 Trig端口
#define Echo1 5    // 正前方传感器 Echo端口
#define Echo2 12    // 正前方舵机传感器 Echo端口
#define Echo3 13    // 右侧方传感器 Echo端口
#define Echo4 14    // 左侧方传感器 Echo端口
#define Echo5 6    // 后方传感器 Echo端口
#define PWM_PIN1 26    // 转向舵机引脚
#define PWM_PIN2 23    // 正前方传感器舵机引脚
#define PWM_PIN3 2    // 后方传感器舵机引脚
#define Zx_Motor_FRAME_HEADER1  0XFA
#define Zx_Motor_FRAME_HEADER2  0XAF
#define Zx_Motor_READ_ANGLE     0X02
#define Zx_Motor_FRAME_END      0XED
#define Zx_Motor_RUNS           0XFD
#define Zx_Motor_RUNN           0XFE
#define uint8     char
#define uint32    unsigned int   
#define GET_LOW_BYTE(A)  ((char)(A))
#define GET_HIGH_BYTE(A) ((char)((A) >> 8))
#define PI acos(-1)
double distances[5];
double SPEED;
int fd=0;

double geted_msg[5];
double vehicle_speed_seted;
double vehicle_gap_seted;
double steer_cmd_seted;
double front_sensor_cmd_seted;
double rear_sensor_cmd_seted;

int rasInit()
{
	 if(wiringPiSetup() == -1)
	 {   
	 	printf(\"硬件初始化失败！\\n\");
	 	return 1;
	 }
  printf(\"wiringPiSetup ok!\\n\");
	pinMode(Trig1, OUTPUT);   // 配置端口为输出模式
	pinMode(Echo1, INPUT);   // 配置端口为输入模式
	pinMode(Echo2, INPUT);   // 配置端口为输入模式
	pinMode(Echo3, INPUT);   // 配置端口为输入模式
	pinMode(Echo4, INPUT);   // 配置端口为输入模式
	pinMode(Echo5, INPUT);   // 配置端口为输入模式
	pullUpDnControl(Echo1, PUD_UP); // 对一个设置 IO 模式为 INPUT 的输入引脚设置拉电阻模式
	pullUpDnControl(Echo2, PUD_UP); // PUD_UP 启用上拉电阻，引脚电平拉到 3.3v
	pullUpDnControl(Echo3, PUD_UP); // PUD_UP 启用上拉电阻，引脚电平拉到 3.3v
	pullUpDnControl(Echo4, PUD_UP); // PUD_UP 启用上拉电阻，引脚电平拉到 3.3v
	pullUpDnControl(Echo5, PUD_UP);	// PUD_UP 启用上拉电阻，引脚电平拉到 3.3v
	pinMode(PWM_PIN1, PWM_OUTPUT);
	pinMode(PWM_PIN2, PWM_OUTPUT);
	pinMode(PWM_PIN3, OUTPUT);
	pwmSetMode(PWM_MODE_MS);
	pwmSetClock(192);
	pwmSetRange(2000);
	softPwmCreate(PWM_PIN3, 0, 200);
	
  printf(\" Raspberry Pi Setup ok!\\n\");
  fd = serialOpen(\"/dev/ttyAMA0\", 115200);
  if(fd == -1)
  {
    printf(\"open serial failed\\n\");
    while(1)
    {}
  }
	return 0;
}

/**
* @brief  获取超声波传感器探测的距离
**/
double getDistance(int echoPin)
{
	double dis;
	long start;
	long end;
	struct timeval tv1;
	struct timeval tv2;
 
  int cot = 0;

	digitalWrite(Trig1, LOW);   // 先通入低电平，避免后续误差过大
	delayMicroseconds(2);
	digitalWrite(Trig1, HIGH);
	delayMicroseconds(10);   // 树莓派发送 10us 脉冲信号
	digitalWrite(Trig1, LOW);

  while((digitalRead(echoPin) != HIGH)&&(cot++ < 31000)); // HIGH（1），检测到高电平时跳出循环
	gettimeofday(&tv1, NULL);   // 获取时间（此为高电平开始时间）
  cot = 0;
  while((digitalRead(echoPin) != LOW)&&(cot++ < 36000));   // LOW（0），检测到低电平跳出循环
	gettimeofday(&tv2, NULL);   // 获取时间（此为低电平开始时间，即为高电平结束时间）
  cot = 0;
	start = tv1.tv_sec * 1000000 + tv1.tv_usec;   // 单位（微秒）
	end = tv2.tv_sec * 1000000 + tv2.tv_usec;   // 单位（微秒）
	dis = (double)(end - start) / 1000000 * 34000 / 2;   // 距离计算（高电平时间 * 音速 / 2）

	delayMicroseconds(15000);   // 树莓派等待10ms
  return dis;
}


/**
* @brief  CRC校验
* @param[in] inst  buf[]
*/
char Zx_MotorCheckSum(char buf[])
{
	int i;
	unsigned int sum = 0;
	for (i = 2; i < 8; i++)
	{
		sum += buf[i];
	}
	if (sum > 255)sum &= 0x00FF;
	return sum;
}

/**
* @brief  电机正转
* @param[in] inst  fd:串口标识位
* @param[in] inst  id:电机id号
* @param[in] inst  speed:车速
*/
void Zx_MotorRunS(double id, double speed)
{
	int rpm = speed / (2 * PI * 3.4) * 60;
	int idi = (int)id;
	char  buf[10];
	buf[0] = 0XFA;
	buf[1] = 0XAF;
	buf[2] = idi;
	buf[3] = 0x01;
	buf[4] = 0XFD;
	buf[5] = 0x00;
	buf[6] = (char)((rpm) >> 8);
	buf[7] = (char)(rpm);
	buf[8] = Zx_MotorCheckSum(buf);
	buf[9] = 0XED;
	write(fd, buf, 10);//将指令发送出去
	delayMicroseconds(10000);   // 树莓派等待50ms
}

/**
* @brief  电机反转
* @param[in] inst  fd:串口标识位
* @param[in] inst  id:电机id号
* @param[in] inst  rpm:给定电机转速
*/
void Zx_MotorRunN(double id, double speed)
{
	int rpm = speed / (2 * PI * 3.4) * 60;
	int idi = (int)id;
	char  buf[10];
	buf[0] = 0XFA;
	buf[1] = 0XAF;
	buf[2] = idi;
	buf[3] = 0x01;
	buf[4] = 0XFE;
	buf[5] = 0x00;
	buf[6] = (char)((rpm) >> 8);
	buf[7] = (char)(rpm);
	buf[8] = Zx_MotorCheckSum(buf);
	buf[9] = 0XED;
	write(fd, buf, 10);//将指令发送出去
	delayMicroseconds(10000);   // 树莓派等待50ms
}

/**
* @brief  获取电机转速
* @param[in] inst  fd:串口文件描述符
* @param[in] inst  id:电机ID号
*/
double GetMotorSpeed(double id)
{
	int idi = (int)id;
	int rpm;
	double speed;
	int n;
	char  buf[10];
	buf[0] = 0XFA;
	buf[1] = 0XAF;
	buf[2] = idi;
	buf[3] = 0X02;
	buf[4] = 0X00;
	buf[5] = 0x00;
	buf[6] = 0x00;
	buf[7] = 0x00;
	buf[8] = Zx_MotorCheckSum(buf);
	buf[9] = 0XED;
	write(fd, buf, 10);//将指令发送出去

	n = read(fd,buf,10);
	if(n!=0)
	{
		rpm = buf[7];
		//printf(\"speed = %d\\n rpm\",rpm);
	}
	speed = rpm * 2 * PI * 3.4 / 60;
  printf(\"speed = %d\\n \",speed);
	return speed;
}

/**
* @brief  运行小车
* @param[in] inst  fd:串口文件描述符
* @param[in] inst  speed:车速
* @param[in] inst  gap:差速
*/
void vehicle_speed(double speed, double gap)
{
  vehicle_speed_seted=speed;
  vehicle_gap_seted=gap;
  
  if(gap > 0.00001)
  {
    gap = gap-(speed*0.1);//标定值
  }
  else
  {
    gap=0;
  }
	
  
	if(speed > 0)
	{
		Zx_MotorRunN(2, speed+gap);   //电机2正转
		Zx_MotorRunS(1, speed-gap);   //电机1正转
	}
	else
	{
		Zx_MotorRunS(2, fabs(speed)+gap);   //电机2反转
		Zx_MotorRunN(1, fabs(speed)-gap);   //电机1反转
	}
  printf(\"\\n rigth speed = %5.2fcm, left speed= %5.2fcm\\n\", speed+gap, speed-gap);
	return;
}

void steer_cmd(double steer)
{
steer_cmd_seted=steer;

	int PulseWidth;
	PulseWidth = (int)(steer*100+150);
	pwmWrite(PWM_PIN1 ,PulseWidth);
  printf(\"steer_cmd:%f\\n\", steer);
  return;
	
}

void front_sensor_cmd(double steer)
{
front_sensor_cmd_seted=steer;

	int PulseWidth;
	PulseWidth = (int)(steer*100+150);
	pwmWrite(PWM_PIN2 ,PulseWidth);
  return;
}

void rear_sensor_cmd(double angle)
{
rear_sensor_cmd_seted=angle;

	int cmd = angle * 20 / 180 + 5;
	softPwmWrite(PWM_PIN3, cmd);
	return;
  //printf(\"可变雷达角度:%f\\n\", angle);
}

/**
* @brief  复位
*/
void reset()
{
  fd = serialOpen(\"/dev/ttyAMA0\", 115200);
  delayMicroseconds(20000);
  vehicle_speed(0, 0);
  steer_cmd(0);
  front_sensor_cmd(0);
  printf(\"reset success!\\n\");
  exit(0);
}

void wait(double delayTime)
{
  delayMicroseconds(delayTime * 1000000);
}

void GetCarMsg(double* sensor1_distence,double* sensor2_distence,double* sensor3_distence,double* sensor4_distence,double* sensor5_distence)
{
	// 获取传感器探测的距离
	*sensor1_distence=getDistance(Echo1);
	*sensor2_distence=getDistance(Echo2);
	*sensor3_distence=getDistance(Echo3);
	*sensor4_distence=getDistance(Echo4);
	*sensor5_distence=getDistance(Echo5);	
  
  geted_msg[0]= *sensor1_distence;
  geted_msg[1]= *sensor2_distence;
  geted_msg[2]= *sensor3_distence;
  geted_msg[3]= *sensor4_distence;
  geted_msg[4]= *sensor5_distence;  
  printf(\"sensor out: front| fl|right| left| fr|\\n\");
  printf(\"sensor out: %5.1f|%5.1f|%5.1f|%5.1f|%5.1f|\\n\",*sensor1_distence ,*sensor2_distence,*sensor3_distence,*sensor4_distence,*sensor5_distence);
}
"    );
    end func_CCaller;
      initial equation

      func_CCaller();
    end CCaller;
    block CCaller1

        annotation(
         __MWORKS(PortArrangement(Left(src), Right(out)),BlockSystem(blockKind = BlockKind.atomic,bltBlockKind = BltBlockKind.ccaller,SampleTime=-1),independentInstance = true,sourceModel = SysplorerEmbeddedCoder.Utilities.CCaller,ExternalFunctionBlock,hide = true), 
              Icon(coordinateSystem(extent = { {-200.0, -100.0}, {200.0, 100.0} }, 
              preserveAspectRatio = false, 
              initialScale = 0.1, 
              grid = { 2.0, 2.0 }), graphics = { Rectangle(origin = {0.0, 0.0}, 
              fillColor = {255, 255, 255}, 
              fillPattern = FillPattern.Solid, 
              extent = {{-200.0, 100.0}, {200.0, -100.0}}), Text(origin = {0.0, 0.0}, 
              extent = {{-200.0, 20.0}, {200, -20}}, 
              textString = "steer_cmd", 
              verticalAlignment = TextAlignment.VCenter), Text(origin = {0.0, -120.0}, 
              lineColor = {0, 0, 0}, 
              extent = {{-150, 20}, {150, -20}}, 
              textString = "%name", 
              fontSize = 14, 
             textStyle = {TextStyle.None}, 
              textColor = {0, 0, 0}, 
              verticalAlignment = TextAlignment.Top) }), 
          Diagram(coordinateSystem(extent = { {-100.0, -100.0}, {100.0, 100.0} }, 
              preserveAspectRatio = false, 
              initialScale = 0.1, 
              grid = { 2.0, 2.0 })));
      function func_CCaller1
      input SysplorerEmbeddedCoder.Types.Auto src annotation(__MWORKS(BlockSystem(Type(inherit = InheritType.none, ref="double"), Dimension(dimensionType = DimensionType.none) = 1)));
    external "C" steer_cmd(src);
    end func_CCaller1;
        SysplorerEmbeddedCoder.Port.Inport src 
        annotation(__MWORKS(BlockSystem(Type(inherit = InheritType.none, ref = "double"),Dimension(dimensionType = DimensionType.none) = 1)), Placement(transformation(origin = {0,0}, extent = { {-10,-10}, {10,10} })));
        equation
      func_CCaller1(src);
    end CCaller1;
    block CCaller3

        annotation(
         __MWORKS(PortArrangement(Left(src), Right(out)),BlockSystem(blockKind = BlockKind.atomic,bltBlockKind = BltBlockKind.ccaller,SampleTime=-1),independentInstance = true,sourceModel = SysplorerEmbeddedCoder.Utilities.CCaller,ExternalFunctionBlock,hide = true), 
              Icon(coordinateSystem(extent = { {-200.0, -100.0}, {200.0, 100.0} }, 
              preserveAspectRatio = false, 
              initialScale = 0.1, 
              grid = { 2.0, 2.0 }), graphics = { Rectangle(origin = {0.0, 0.0}, 
              fillColor = {255, 255, 255}, 
              fillPattern = FillPattern.Solid, 
              extent = {{-200.0, 100.0}, {200.0, -100.0}}), Text(origin = {0.0, 0.0}, 
              extent = {{-200.0, 20.0}, {200, -20}}, 
              textString = "front_sensor_cmd", 
              verticalAlignment = TextAlignment.VCenter), Text(origin = {0.0, -120.0}, 
              lineColor = {0, 0, 0}, 
              extent = {{-150, 20}, {150, -20}}, 
              textString = "%name", 
              fontSize = 14, 
             textStyle = {TextStyle.None}, 
              textColor = {0, 0, 0}, 
              verticalAlignment = TextAlignment.Top) }), 
          Diagram(coordinateSystem(extent = { {-100.0, -100.0}, {100.0, 100.0} }, 
              preserveAspectRatio = false, 
              initialScale = 0.1, 
              grid = { 2.0, 2.0 })));
    function func_CCaller3
      input SysplorerEmbeddedCoder.Types.Auto src annotation(__MWORKS(BlockSystem(Type(inherit = InheritType.none, ref="double"), Dimension(dimensionType = DimensionType.none) = 1)));
    external "C" front_sensor_cmd(src);
    end func_CCaller3;
        SysplorerEmbeddedCoder.Port.Inport src 
        annotation(__MWORKS(BlockSystem(Type(inherit = InheritType.none, ref = "double"),Dimension(dimensionType = DimensionType.none) = 1)), Placement(transformation(origin = {0,0}, extent = { {-10,-10}, {10,10} })));
        equation
      func_CCaller3(src);
    end CCaller3;
    block CCaller4

        annotation(
         __MWORKS(PortArrangement(Left(src), Right(out)),BlockSystem(blockKind = BlockKind.atomic,bltBlockKind = BltBlockKind.ccaller,SampleTime=-1),independentInstance = true,sourceModel = SysplorerEmbeddedCoder.Utilities.CCaller,ExternalFunctionBlock,hide = true), 
              Icon(coordinateSystem(extent = { {-200.0, -100.0}, {200.0, 100.0} }, 
              preserveAspectRatio = false, 
              initialScale = 0.1, 
              grid = { 2.0, 2.0 }), graphics = { Rectangle(origin = {0.0, 0.0}, 
              fillColor = {255, 255, 255}, 
              fillPattern = FillPattern.Solid, 
              extent = {{-200.0, 100.0}, {200.0, -100.0}}), Text(origin = {0.0, 0.0}, 
              extent = {{-200.0, 20.0}, {200, -20}}, 
              textString = "rear_sensor_cmd", 
              verticalAlignment = TextAlignment.VCenter), Text(origin = {0.0, -120.0}, 
              lineColor = {0, 0, 0}, 
              extent = {{-150, 20}, {150, -20}}, 
              textString = "%name", 
              fontSize = 14, 
             textStyle = {TextStyle.None}, 
              textColor = {0, 0, 0}, 
              verticalAlignment = TextAlignment.Top) }), 
          Diagram(coordinateSystem(extent = { {-100.0, -100.0}, {100.0, 100.0} }, 
              preserveAspectRatio = false, 
              initialScale = 0.1, 
              grid = { 2.0, 2.0 })));
      function func_CCaller4
      input SysplorerEmbeddedCoder.Types.Auto src annotation(__MWORKS(BlockSystem(Type(inherit = InheritType.none, ref="double"), Dimension(dimensionType = DimensionType.none) = 1)));
    external "C" rear_sensor_cmd(src);
    end func_CCaller4;
        SysplorerEmbeddedCoder.Port.Inport src 
        annotation(__MWORKS(BlockSystem(Type(inherit = InheritType.none, ref = "double"),Dimension(dimensionType = DimensionType.none) = 1)), Placement(transformation(origin = {0,0}, extent = { {-10,-10}, {10,10} })));
        equation
      func_CCaller4(src);
    end CCaller4;
    CCaller2 c_caller2 
      annotation (Placement(transformation(origin={76,75.1334}, 
    extent={{-20,-34.8667},{20,34.8667}})),__MWORKS(BlockSystem(SampleTime(group="D1")=0.02),ComponentNamePlacement(BOTTOM)));
    CCaller c_caller 
      annotation (Placement(transformation(origin={76,132}, 
    extent={{-20,-10},{20,10}})),__MWORKS(BlockSystem(SampleTime(group="D1")=0.02)));
    CCaller1 c_caller1 
      annotation (Placement(transformation(origin={76,6}, 
    extent={{-20,-10},{20,10}})),__MWORKS(BlockSystem(SampleTime(group="D1")=0.02)));
    CCaller3 c_caller3 
      annotation (Placement(transformation(origin={76,-30}, 
    extent={{-20,-10},{20,10}})),__MWORKS(BlockSystem(SampleTime(group="D1")=0.02)));
    CCaller4 c_caller4 
      annotation (Placement(transformation(origin={76,-76}, 
    extent={{-20,-10},{20,10}})),__MWORKS(BlockSystem(SampleTime(group="D1")=0.02)));
    SysplorerEmbeddedCoder.Port.Inport speed 
        annotation ( __MWORKS(BlockSystem(Type(inherit=InheritType.none ,ref="double") ,Dimension(dimensionType=DimensionType.auto)=1,SampleTime(auto=true,group="D1")=0.02)),Placement(transformation(extent = { {40.6, 88.9668}, {47.8, 96.1667}})));
    SysplorerEmbeddedCoder.Port.Inport gap 
        annotation ( __MWORKS(BlockSystem(Type(inherit=InheritType.none ,ref="double") ,Dimension(dimensionType=DimensionType.auto)=1,SampleTime(auto=true,group="D1")=0.02)),Placement(transformation(extent = { {40.6, 54.1}, {47.8, 61.3}})));
    SysplorerEmbeddedCoder.Port.Inport steer 
        annotation ( __MWORKS(BlockSystem(Type(inherit=InheritType.none ,ref="double") ,Dimension(dimensionType=DimensionType.auto)=1,SampleTime(auto=true,group="D1")=0.02)),Placement(transformation(extent = { {40.6, 2.4}, {47.8, 9.6}})));
    SysplorerEmbeddedCoder.Port.Inport u4 
        annotation ( __MWORKS(BlockSystem(Type(inherit=InheritType.none ,ref="double") ,Dimension(dimensionType=DimensionType.auto)=1,SampleTime(auto=true,group="D1")=0.02)),Placement(transformation(extent = { {40.6, -33.6}, {47.8, -26.4}})));
    SysplorerEmbeddedCoder.Port.Inport u5 
        annotation ( __MWORKS(BlockSystem(Type(inherit=InheritType.none ,ref="double") ,Dimension(dimensionType=DimensionType.auto)=1,SampleTime(auto=true,group="D1")=0.02)),Placement(transformation(extent = { {40.6, -79.6}, {47.8, -72.4}})));
  equation
    connect(speed, c_caller2.speed) 
      annotation (Line(origin = {0, 0}, 
                points = { {0, 0}, {0, 0} }, 
                color = { 0, 0, 0 }));
    connect(gap, c_caller2.gap) 
      annotation (Line(origin = {0, 0}, 
                points = { {0, 0}, {0, 0} }, 
                color = { 0, 0, 0 }));
    connect(steer, c_caller1.src) 
      annotation (Line(origin = {0, 0}, 
                points = { {0, 0}, {0, 0} }, 
                color = { 0, 0, 0 }));
    connect(u4, c_caller3.src) 
      annotation (Line(origin = {0, 0}, 
                points = { {0, 0}, {0, 0} }, 
                color = { 0, 0, 0 }));
    connect(u5, c_caller4.src) 
      annotation (Line(origin = {0, 0}, 
                points = { {0, 0}, {0, 0} }, 
                color = { 0, 0, 0 }));
    end SubSystem1;
  equation
  connect(constant1.y, raspberry_SetMsg.u5) 
  annotation(Line(origin={26.9,-5.12449}, 
points={{-74.1,-12.87551},{29.1,-12.87551},{29.1,21.5139},{47.3,21.5139}}, 
color={0,0,0}),__MWORKS(BlockSystem(NamedSignal)));
  connect(raspberry_GetMsg1.dis1, aPF.front_dist) 
  annotation(Line(origin={-128,68}, 
points={{-37.2,0.26548},{30.2,0.26548},{30.2,6.24496}}, 
color={0,0,0}));
  connect(raspberry_GetMsg1.dis2, aPF.fl_dist) 
  annotation(Line(origin={-128,54}, 
points={{-37.2,0.089},{30.2,0.089},{30.2,6.06848}}, 
color={0,0,0}));
  connect(raspberry_GetMsg1.dis3, aPF.right_dist) 
  annotation(Line(origin={-128,40}, 
points={{-37.2,-0.08748},{30.2,-0.08748},{30.2,5.892}}, 
color={0,0,0}));
  connect(raspberry_GetMsg1.dis4, aPF.left_dist) 
  annotation(Line(origin={-128,26}, 
points={{-37.2,-0.26396},{30.2,-0.26396},{30.2,5.71552}}, 
color={0,0,0}));
  connect(raspberry_GetMsg1.dis5, aPF.fr_dist) 
  annotation(Line(origin={-128,12}, 
points={{-37.2,-0.44044},{30.2,-0.44044},{30.2,5.53904}}, 
color={0,0,0}));
  connect(aPF.speed, raspberry_SetMsg.speed) 
  annotation(Line(origin={30,64}, 
points={{-50.2,5.51947},{44.2,5.51947},{44.2,-0.10162}}, 
color={0,0,0}));
  connect(aPF.steer, raspberry_SetMsg.steer) 
  annotation(Line(origin={30,40}, 
points={{-50.2,5.892},{44.2,5.892},{44.2,0.1439}}, 
color={0,0,0}));
  connect(aPF.gap, raspberry_SetMsg.gap) 
  annotation(Line(origin={30,34}, 
points={{-50.2,-11.7355},{-50.2,18.0211},{44.2,18.0211}}, 
color={0,0,0}));
  connect(constant1.y, raspberry_SetMsg.u4) 
  annotation(Line(origin={13,5}, 
  points={{-60.2,-23},{61.2,-23},{61.2,23.26666}}, 
  color={0,0,0}),__MWORKS(BlockSystem(NamedSignal)));
  end APF;