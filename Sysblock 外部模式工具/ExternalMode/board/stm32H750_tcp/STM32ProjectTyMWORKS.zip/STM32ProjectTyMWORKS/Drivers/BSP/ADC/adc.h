//#ifndef __ADC_H
//#define __ADC_H

//#include "./SYSTEM/sys/sys.h"

///* ADC���� */
////#define ADC_ADCX                                ADC1
////#define ADC_ADCX_CLK_ENABLE()                   do { __HAL_RCC_ADC12_CLK_ENABLE(); } while (0)
////#define ADC_ADCX_CHY                            ADC_CHANNEL_19
////#define ADC_ADCX_CHY_GPIO_PORT                  GPIOA
////#define ADC_ADCX_CHY_GPIO_PIN                   GPIO_PIN_5
////#define ADC_ADCX_CHY_GPIO_CLK_ENABLE()          do { __HAL_RCC_GPIOA_CLK_ENABLE(); } while (0)

////#define ADC_DMA_ADCX                            ADC1
////#define ADC_DMA_ADCX_CLK_ENABLE();              do { __HAL_RCC_ADC12_CLK_ENABLE(); } while (0)
////#define ADC_DMA_ADCX_CHY                        ADC_CHANNEL_19
////#define ADC_DMA_ADCX_CHY_GPIO_PORT              GPIOA
////#define ADC_DMA_ADCX_CHY_GPIO_PIN               GPIO_PIN_5
////#define ADC_DMA_ADCX_CHY_GPIO_CLK_ENABLE()      do { __HAL_RCC_GPIOA_CLK_ENABLE(); } while (0)
////#define ADC_DMA_ADCX_DMASX                      DMA1_Stream0
////#define ADC_DMA_ADCX_DMA_CLK_ENABLE()           do { __HAL_RCC_DMA1_CLK_ENABLE(); } while (0)
////#define ADC_DMA_ADCX_DMASX_REQ                  DMA_REQUEST_ADC1
////#define ADC_DMA_ADCX_DMASX_IRQn                 DMA1_Stream0_IRQn
////#define ADC_DMA_ADCX_DMASX_IRQHandler           DMA1_Stream0_IRQHandler

////#define ADC_NCH_DMA_ADCX                        ADC2
////#define ADC_NCH_DMA_ADCX_CLK_ENABLE()           do { __HAL_RCC_ADC12_CLK_ENABLE(); } while (0)
////#define ADC_NCH_DMA_ADCX_CH_NUM                 2
////#define ADC_NCH_DMA_ADCX_CHA                    ADC_CHANNEL_18
////#define ADC_NCH_DMA_ADCX_CHA_GPIO_PORT          GPIOA
////#define ADC_NCH_DMA_ADCX_CHA_GPIO_PIN           GPIO_PIN_4
////#define ADC_NCH_DMA_ADCX_CHA_GPIO_CLK_ENABLE()  do { __HAL_RCC_GPIOA_CLK_ENABLE(); } while (0)
////#define ADC_NCH_DMA_ADCX_CHB                    ADC_CHANNEL_19
////#define ADC_NCH_DMA_ADCX_CHB_GPIO_PORT          GPIOA
////#define ADC_NCH_DMA_ADCX_CHB_GPIO_PIN           GPIO_PIN_5
////#define ADC_NCH_DMA_ADCX_CHB_GPIO_CLK_ENABLE()  do { __HAL_RCC_GPIOA_CLK_ENABLE(); } while (0)
////#define ADC_NCH_DMA_ADCX_DMASX                  DMA1_Stream1
////#define ADC_NCH_DMA_ADCX_DMA_CLK_ENABLE()       do { __HAL_RCC_DMA1_CLK_ENABLE(); } while (0)
////#define ADC_NCH_DMA_ADCX_DMASX_REQ              DMA_REQUEST_ADC2
////#define ADC_NCH_DMA_ADCX_DMASX_IRQn             DMA1_Stream1_IRQn
////#define ADC_NCH_DMA_ADCX_DMASX_IRQHandler       DMA1_Stream1_IRQHandler

////#define ADC_OS_ADCX                             ADC1
////#define ADC_OS_ADCX_CLK_ENABLE()                do { __HAL_RCC_ADC12_CLK_ENABLE(); } while (0)
////#define ADC_OS_ADCX_CHY                         ADC_CHANNEL_19
////#define ADC_OS_ADCX_CHY_GPIO_PORT               GPIOA
////#define ADC_OS_ADCX_CHY_GPIO_PIN                GPIO_PIN_5
////#define ADC_OS_ADCX_CHY_GPIO_CLK_ENABLE()       do { __HAL_RCC_GPIOA_CLK_ENABLE(); } while (0)

///*
//    PA0     ------> ADC1_INP16
//    PA6     ------> ADC1_INP3
//    PA1_C   ------> ADC1_INP1
//    PB1     ------> ADC1_INP5

//    PA0_C   ------> ADC2_INP0
//    PA3     ------> ADC2_INP15
//    PB0     ------> ADC2_INP9

//    PF6     ------> ADC3_INP8
//    PF7     ------> ADC3_INP3
//    PF8     ------> ADC3_INP7
//    PC0     ------> ADC3_INP10
//    PF10    ------> ADC3_INP6
//    PF9     ------> ADC3_INP2
//    PH2     ------> ADC3_INP13
//    PH3     ------> ADC3_INP14
//    PH4     ------> ADC3_INP15
//    PC2_C   ------> ADC3_INP0
//    PC3_C   ------> ADC3_INP1
//*/
//#define ADC1_A1_CH           ADC_CHANNEL_1

//#define ADC1_A2_CH           ADC_CHANNEL_3
//#define ADC1_A2_PORT         GPIOA
//#define ADC1_A2_PIN          GPIO_PIN_6
//#define ADC1_A3_CH           ADC_CHANNEL_5
//#define ADC1_A3_PORT         GPIOB
//#define ADC1_A3_PIN          GPIO_PIN_1
//#define ADC1_A4_CH           ADC_CHANNEL_16
//#define ADC1_A4_PORT         GPIOA
//#define ADC1_A4_PIN          GPIO_PIN_0

//#define ADC2_A1_CH           ADC_CHANNEL_0

//#define ADC2_A2_CH           ADC_CHANNEL_9
//#define ADC2_A2_PORT         GPIOB
//#define ADC2_A2_PIN          GPIO_PIN_0
//#define ADC2_A3_CH           ADC_CHANNEL_15
//#define ADC2_A3_PORT         GPIOA
//#define ADC2_A3_PIN          GPIO_PIN_3

//#define ADC3_A1_CH           ADC_CHANNEL_0
//#define ADC3_A2_CH           ADC_CHANNEL_1

//#define ADC3_A3_CH           ADC_CHANNEL_2
//#define ADC3_A3_PORT         GPIOF
//#define ADC3_A3_PIN          GPIO_PIN_9
//#define ADC3_A4_CH           ADC_CHANNEL_3
//#define ADC3_A4_PORT         GPIOF
//#define ADC3_A4_PIN          GPIO_PIN_7
//#define ADC3_A5_CH           ADC_CHANNEL_6
//#define ADC3_A5_PORT         GPIOF
//#define ADC3_A5_PIN          GPIO_PIN_10
//#define ADC3_A6_CH           ADC_CHANNEL_7
//#define ADC3_A6_PORT         GPIOF
//#define ADC3_A6_PIN          GPIO_PIN_8
//#define ADC3_A7_CH           ADC_CHANNEL_8
//#define ADC3_A7_PORT         GPIOF
//#define ADC3_A7_PIN          GPIO_PIN_6
//#define ADC3_A8_CH           ADC_CHANNEL_10
//#define ADC3_A8_PORT         GPIOC
//#define ADC3_A8_PIN          GPIO_PIN_0
//#define ADC3_A9_CH           ADC_CHANNEL_13
//#define ADC3_A9_PORT         GPIOH
//#define ADC3_A9_PIN          GPIO_PIN_2
//#define ADC3_A10_CH          ADC_CHANNEL_14
//#define ADC3_A10_PORT        GPIOH
//#define ADC3_A10_PIN         GPIO_PIN_3
//#define ADC3_A11_CH          ADC_CHANNEL_15
//#define ADC3_A11_PORT        GPIOH
//#define ADC3_A11_PIN         GPIO_PIN_4

//#define ADC1_DMA_STREAM      DMA1_Stream0
//#define ADC2_DMA_STREAM      DMA1_Stream1
//#define ADC3_DMA_STREAM      DMA1_Stream2

//#define ADC1_DMA_REQ         DMA_REQUEST_ADC1
//#define ADC2_DMA_REQ         DMA_REQUEST_ADC2
//#define ADC3_DMA_REQ         DMA_REQUEST_ADC3

//#define ADC1_DMA_IRQn        DMA1_Stream0_IRQn
//#define ADC1_DMA_IRQHandler  DMA1_Stream0_IRQHandler
//#define ADC2_DMA_IRQn        DMA1_Stream1_IRQn
//#define ADC2_DMA_IRQHandler  DMA1_Stream1_IRQHandler
//#define ADC3_DMA_IRQn        DMA1_Stream2_IRQn
//#define ADC3_DMA_IRQHandler  DMA1_Stream2_IRQHandler

//#define ADC1_DMA_NUM        2   //ADC1ͨ����
//#define ADC2_DMA_NUM        3//3   //ADC2ͨ����
//#define ADC3_DMA_NUM        11//11  //ADC3ͨ����

//#define ADC_SAMPLE_CNT      1//20  //ADC���������

//#define ADC1_RNUM           ADC_SAMPLE_CNT
//#define ADC2_RNUM           ADC_SAMPLE_CNT
//#define ADC3_RNUM           ADC_SAMPLE_CNT

//#define ADC1_DMA_BUF_SIZE   (ADC1_RNUM * ADC1_DMA_NUM)  //ADC1����ͨ���������С
//#define ADC2_DMA_BUF_SIZE   (ADC2_RNUM * ADC2_DMA_NUM)	//ADC2����ͨ���������С
//#define ADC3_DMA_BUF_SIZE   (ADC3_RNUM * ADC3_DMA_NUM)	//ADC3����ͨ���������С


//#define ADC_AIN1        ADC1_A3_CH
//#define ADC_AIN2        ADC2_A2_CH
//#define ADC_AIN3        ADC1_A4_CH
//#define ADC_AIN4        ADC3_A3_CH
//#define ADC_AIN5        ADC1_A2_CH
//#define ADC_AIN6        ADC3_A2_CH
//#define ADC_AIN7        ADC3_A1_CH
//#define ADC_AIN8        ADC3_A11_CH
//#define ADC_AIN9        ADC3_A9_CH
//#define ADC_AIN10       ADC3_A10_CH
//#define ADC_AIN11       ADC3_A5_CH
//#define ADC_AIN12       ADC3_A8_CH
//#define ADC_AIN13       ADC3_A4_CH
//#define ADC_AIN14       ADC3_A7_CH
//#define ADC_AIN15       ADC3_A6_CH
//#define ADC_AIN16       ADC2_A3_CH

//#define ADC_AIN1C       ADC1_A1_CH
//#define ADC_AIN2C       ADC2_A1_CH


//extern ADC_HandleTypeDef adc1_handle;
//extern uint8_t adc_result_value[60];
//extern uint8_t adc_result_size;
//extern uint8_t adc_start_flag;

////extern unsigned int adcBuff1[2];


///* �������� */
//void adc_init(void);                                                /* ��ʼ��ADC */
//uint32_t adc_get_result(uint32_t channel);                          /* ��ȡADC��� */
//uint32_t adc_get_result_average(uint32_t channel, uint8_t times);   /* ��ֵ�˲���ȡADC��� */

//void adc_dma_init(void);                                            /* ��ʼ��ADC DMA��ȡ */

//void adc1_dma_enable(uint32_t length);                               /* ����ADC DMA��ȡ */
//void adc2_dma_enable(uint32_t length);                               /* ����ADC DMA��ȡ */
//void adc3_dma_enable(uint32_t length);                               /* ����ADC DMA��ȡ */

//void adc_oversample_init(uint32_t ratio, uint32_t right_shift);     /* ��ʼ��ADC������ */
//void adc_set_param(uint8_t resolution,uint16_t enable_16c,uint8_t enable_2c,uint8_t cycle);
//void adc_dma_start(ADC_HandleTypeDef *hadc,__IO uint16_t pData[],uint8_t cycle,uint8_t num,uint32_t ch[]);
//void adc_start(void);

//void adc_result(void);
//void adc_stop(void);

//#endif


#ifndef __ADC_H
#define __ADC_H

#include "./SYSTEM/sys/sys.h"

/* ADC���� */
//#define ADC_ADCX                                ADC1
//#define ADC_ADCX_CLK_ENABLE()                   do { __HAL_RCC_ADC12_CLK_ENABLE(); } while (0)
//#define ADC_ADCX_CHY                            ADC_CHANNEL_19
//#define ADC_ADCX_CHY_GPIO_PORT                  GPIOA
//#define ADC_ADCX_CHY_GPIO_PIN                   GPIO_PIN_5
//#define ADC_ADCX_CHY_GPIO_CLK_ENABLE()          do { __HAL_RCC_GPIOA_CLK_ENABLE(); } while (0)

//#define ADC_DMA_ADCX                            ADC1
//#define ADC_DMA_ADCX_CLK_ENABLE();              do { __HAL_RCC_ADC12_CLK_ENABLE(); } while (0)
//#define ADC_DMA_ADCX_CHY                        ADC_CHANNEL_19
//#define ADC_DMA_ADCX_CHY_GPIO_PORT              GPIOA
//#define ADC_DMA_ADCX_CHY_GPIO_PIN               GPIO_PIN_5
//#define ADC_DMA_ADCX_CHY_GPIO_CLK_ENABLE()      do { __HAL_RCC_GPIOA_CLK_ENABLE(); } while (0)
//#define ADC_DMA_ADCX_DMASX                      DMA1_Stream0
//#define ADC_DMA_ADCX_DMA_CLK_ENABLE()           do { __HAL_RCC_DMA1_CLK_ENABLE(); } while (0)
//#define ADC_DMA_ADCX_DMASX_REQ                  DMA_REQUEST_ADC1
//#define ADC_DMA_ADCX_DMASX_IRQn                 DMA1_Stream0_IRQn
//#define ADC_DMA_ADCX_DMASX_IRQHandler           DMA1_Stream0_IRQHandler

//#define ADC_NCH_DMA_ADCX                        ADC2
//#define ADC_NCH_DMA_ADCX_CLK_ENABLE()           do { __HAL_RCC_ADC12_CLK_ENABLE(); } while (0)
//#define ADC_NCH_DMA_ADCX_CH_NUM                 2
//#define ADC_NCH_DMA_ADCX_CHA                    ADC_CHANNEL_18
//#define ADC_NCH_DMA_ADCX_CHA_GPIO_PORT          GPIOA
//#define ADC_NCH_DMA_ADCX_CHA_GPIO_PIN           GPIO_PIN_4
//#define ADC_NCH_DMA_ADCX_CHA_GPIO_CLK_ENABLE()  do { __HAL_RCC_GPIOA_CLK_ENABLE(); } while (0)
//#define ADC_NCH_DMA_ADCX_CHB                    ADC_CHANNEL_19
//#define ADC_NCH_DMA_ADCX_CHB_GPIO_PORT          GPIOA
//#define ADC_NCH_DMA_ADCX_CHB_GPIO_PIN           GPIO_PIN_5
//#define ADC_NCH_DMA_ADCX_CHB_GPIO_CLK_ENABLE()  do { __HAL_RCC_GPIOA_CLK_ENABLE(); } while (0)
//#define ADC_NCH_DMA_ADCX_DMASX                  DMA1_Stream1
//#define ADC_NCH_DMA_ADCX_DMA_CLK_ENABLE()       do { __HAL_RCC_DMA1_CLK_ENABLE(); } while (0)
//#define ADC_NCH_DMA_ADCX_DMASX_REQ              DMA_REQUEST_ADC2
//#define ADC_NCH_DMA_ADCX_DMASX_IRQn             DMA1_Stream1_IRQn
//#define ADC_NCH_DMA_ADCX_DMASX_IRQHandler       DMA1_Stream1_IRQHandler

//#define ADC_OS_ADCX                             ADC1
//#define ADC_OS_ADCX_CLK_ENABLE()                do { __HAL_RCC_ADC12_CLK_ENABLE(); } while (0)
//#define ADC_OS_ADCX_CHY                         ADC_CHANNEL_19
//#define ADC_OS_ADCX_CHY_GPIO_PORT               GPIOA
//#define ADC_OS_ADCX_CHY_GPIO_PIN                GPIO_PIN_5
//#define ADC_OS_ADCX_CHY_GPIO_CLK_ENABLE()       do { __HAL_RCC_GPIOA_CLK_ENABLE(); } while (0)

/*
    PA0     ------> ADC1_INP16
    PA6     ------> ADC1_INP3
    PA1_C   ------> ADC1_INP1
    PB1     ------> ADC1_INP5

    PA0_C   ------> ADC2_INP0
    PA3     ------> ADC2_INP15
    PB0     ------> ADC2_INP9

    PF6     ------> ADC3_INP8
    PF7     ------> ADC3_INP3
    PF8     ------> ADC3_INP7
    PC0     ------> ADC3_INP10
    PF10    ------> ADC3_INP6
    PF9     ------> ADC3_INP2
    PH2     ------> ADC3_INP13
    PH3     ------> ADC3_INP14
    PH4     ------> ADC3_INP15
    PC2_C   ------> ADC3_INP0
    PC3_C   ------> ADC3_INP1
*/
#define ADC1_A1_CH           ADC_CHANNEL_1

#define ADC1_A2_CH           ADC_CHANNEL_3
#define ADC1_A2_PORT         GPIOA
#define ADC1_A2_PIN          GPIO_PIN_6
#define ADC1_A3_CH           ADC_CHANNEL_5
#define ADC1_A3_PORT         GPIOB
#define ADC1_A3_PIN          GPIO_PIN_1
#define ADC1_A4_CH           ADC_CHANNEL_16
#define ADC1_A4_PORT         GPIOA
#define ADC1_A4_PIN          GPIO_PIN_0

#define ADC2_A1_CH           ADC_CHANNEL_0

#define ADC2_A2_CH           ADC_CHANNEL_9
#define ADC2_A2_PORT         GPIOB
#define ADC2_A2_PIN          GPIO_PIN_0
#define ADC2_A3_CH           ADC_CHANNEL_15
#define ADC2_A3_PORT         GPIOA
#define ADC2_A3_PIN          GPIO_PIN_3

#define ADC3_A1_CH           ADC_CHANNEL_0
#define ADC3_A2_CH           ADC_CHANNEL_1

#define ADC3_A3_CH           ADC_CHANNEL_2
#define ADC3_A3_PORT         GPIOF
#define ADC3_A3_PIN          GPIO_PIN_9
#define ADC3_A4_CH           ADC_CHANNEL_3
#define ADC3_A4_PORT         GPIOF
#define ADC3_A4_PIN          GPIO_PIN_7
#define ADC3_A5_CH           ADC_CHANNEL_6
#define ADC3_A5_PORT         GPIOF
#define ADC3_A5_PIN          GPIO_PIN_10
#define ADC3_A6_CH           ADC_CHANNEL_7
#define ADC3_A6_PORT         GPIOF
#define ADC3_A6_PIN          GPIO_PIN_8
#define ADC3_A7_CH           ADC_CHANNEL_8
#define ADC3_A7_PORT         GPIOF
#define ADC3_A7_PIN          GPIO_PIN_6
#define ADC3_A8_CH           ADC_CHANNEL_10
#define ADC3_A8_PORT         GPIOC
#define ADC3_A8_PIN          GPIO_PIN_0
#define ADC3_A9_CH           ADC_CHANNEL_13
#define ADC3_A9_PORT         GPIOH
#define ADC3_A9_PIN          GPIO_PIN_2
#define ADC3_A10_CH          ADC_CHANNEL_14
#define ADC3_A10_PORT        GPIOH
#define ADC3_A10_PIN         GPIO_PIN_3
#define ADC3_A11_CH          ADC_CHANNEL_15
#define ADC3_A11_PORT        GPIOH
#define ADC3_A11_PIN         GPIO_PIN_4

#define ADC1_DMA_STREAM      DMA1_Stream0
#define ADC2_DMA_STREAM      DMA1_Stream1
#define ADC3_DMA_STREAM      DMA1_Stream2

#define ADC1_DMA_REQ         DMA_REQUEST_ADC1
#define ADC2_DMA_REQ         DMA_REQUEST_ADC2
#define ADC3_DMA_REQ         DMA_REQUEST_ADC3

#define ADC1_DMA_IRQn        DMA1_Stream0_IRQn
#define ADC1_DMA_IRQHandler  DMA1_Stream0_IRQHandler
#define ADC2_DMA_IRQn        DMA1_Stream1_IRQn
#define ADC2_DMA_IRQHandler  DMA1_Stream1_IRQHandler
#define ADC3_DMA_IRQn        DMA1_Stream2_IRQn
#define ADC3_DMA_IRQHandler  DMA1_Stream2_IRQHandler

#define ADC1_DMA_NUM        4 
#define ADC2_DMA_NUM        3 
#define ADC3_DMA_NUM        11 

#define ADC_SAMPLE_CNT      10//20

#define ADC1_RNUM           ADC_SAMPLE_CNT
#define ADC2_RNUM           ADC_SAMPLE_CNT
#define ADC3_RNUM           ADC_SAMPLE_CNT

#define ADC1_DMA_BUF_SIZE   (ADC1_RNUM * ADC1_DMA_NUM)
#define ADC2_DMA_BUF_SIZE   (ADC2_RNUM * ADC2_DMA_NUM)
#define ADC3_DMA_BUF_SIZE   (ADC3_RNUM * ADC3_DMA_NUM)


#define ADC_AIN1        ADC1_A3_CH
#define ADC_AIN2        ADC2_A2_CH
#define ADC_AIN3        ADC1_A4_CH
#define ADC_AIN4        ADC3_A3_CH
#define ADC_AIN5        ADC1_A2_CH
#define ADC_AIN6        ADC3_A2_CH
#define ADC_AIN7        ADC3_A1_CH
#define ADC_AIN8        ADC3_A11_CH
#define ADC_AIN9        ADC3_A9_CH
#define ADC_AIN10       ADC3_A10_CH
#define ADC_AIN11       ADC3_A5_CH
#define ADC_AIN12       ADC3_A8_CH
#define ADC_AIN13       ADC3_A4_CH
#define ADC_AIN14       ADC3_A7_CH
#define ADC_AIN15       ADC3_A6_CH
#define ADC_AIN16       ADC2_A3_CH

#define ADC_AIN1C       ADC1_A1_CH
#define ADC_AIN2C       ADC2_A1_CH



extern uint8_t adc_result_value[60];
extern uint8_t adc_result_size;
extern uint8_t adc_start_flag;


/* �������� */
void adc_init(void);                                                /* ��ʼ��ADC */
uint32_t adc_get_result(uint32_t channel);                          /* ��ȡADC��� */
uint32_t adc_get_result_average(uint32_t channel, uint8_t times);   /* ��ֵ�˲���ȡADC��� */

void adc_dma_init(void);                                            /* ��ʼ��ADC DMA��ȡ */

void adc1_dma_enable(uint32_t length);                               /* ����ADC DMA��ȡ */
void adc2_dma_enable(uint32_t length);                               /* ����ADC DMA��ȡ */
void adc3_dma_enable(uint32_t length);                               /* ����ADC DMA��ȡ */

void adc_oversample_init(uint32_t ratio, uint32_t right_shift);     /* ��ʼ��ADC������ */
void adc_set_param(uint8_t resolution,uint16_t enable_16c,uint8_t enable_2c,uint8_t cycle);
void adc_dma_start(ADC_HandleTypeDef *hadc,__IO  unsigned short pData[],uint8_t cycle,uint8_t num,uint32_t ch[]);
void adc_start(uint16_t enable_16c,uint16_t enable_2c);

void adc_result(void);
void adc_stop(void);

#endif



