#include "./BSP/DAC/dac.h"
#include "./SYSTEM/delay/delay.h"

/* DAC��� */
DAC_HandleTypeDef dac_ch1_handle = {0};
DAC_HandleTypeDef dac_ch1_dma_handle = {0};

DAC_HandleTypeDef dac_ch2_handle = {0};
DAC_HandleTypeDef dac_ch2_dma_handle = {0};


/* DAC DMA�����ر��� */
DMA_HandleTypeDef dma_dac_ch1_handle = {0};
DMA_HandleTypeDef dma_dac_ch2_handle = {0};

TIM_HandleTypeDef dac_dma_tim_handle = {0};

/* ���Ҳ����ݻ����� */
//uint16_t g_dac_sin_buf[4096];

/**
 * @brief   ��ʼ��DAC
 * @param   ��
 * @retval  ��
 */
void dac_init(void)
{
    GPIO_InitTypeDef gpio_init_struct = {0};
    DAC_ChannelConfTypeDef dac_channel_conf_struct = {0};
    
    /* ʹ��ʱ�� */
    __HAL_RCC_DAC12_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /**DAC1 GPIO Configuration
    PA5     ------> DAC1_OUT2
    PA4     ------> DAC1_OUT1
    */    
    /* ����DAC������� */
    gpio_init_struct.Pin = DAC_DMA_PIN1;
    gpio_init_struct.Mode = GPIO_MODE_ANALOG;
    HAL_GPIO_Init(DAC_DMA_PORT1, &gpio_init_struct);
 
    gpio_init_struct.Pin = DAC_DMA_PIN2;
    HAL_GPIO_Init(DAC_DMA_PORT2, &gpio_init_struct);
    
    /* ����DACͨ�� */
    dac_channel_conf_struct.DAC_SampleAndHold = DAC_SAMPLEANDHOLD_DISABLE;          /* ģʽ */
    dac_channel_conf_struct.DAC_Trigger = DAC_TRIGGER_NONE;                         /* ����Դ */
    dac_channel_conf_struct.DAC_OutputBuffer = DAC_OUTPUTBUFFER_DISABLE;            /* ������� */
    dac_channel_conf_struct.DAC_ConnectOnChipPeripheral = DAC_CHIPCONNECT_EXTERNAL; /* �����Ƭ������ */
    dac_channel_conf_struct.DAC_UserTrimming = DAC_TRIMMING_FACTORY;                /* ΢�� */
    dac_channel_conf_struct.DAC_TrimmingValue = 1;                                  /* ΢��ֵ */
    dac_channel_conf_struct.DAC_SampleAndHoldConfig.DAC_SampleTime = 0;             /* �����ͱ���ģʽ�µĲ���ʱ�� */
    dac_channel_conf_struct.DAC_SampleAndHoldConfig.DAC_HoldTime = 0;               /* �����ͱ���ģʽ�µı���ʱ�� */
    dac_channel_conf_struct.DAC_SampleAndHoldConfig.DAC_RefreshTime = 0;            /* �����ͱ���ģʽ�µ�ˢ��ʱ�� */
    HAL_DAC_ConfigChannel(&dac_ch1_handle, &dac_channel_conf_struct, DAC_DMA_CH1);
    HAL_DAC_ConfigChannel(&dac_ch2_handle, &dac_channel_conf_struct, DAC_DMA_CH2);
    
    /* ����DAC */
    dac_ch1_handle.Instance = DAC1;
    dac_ch2_handle.Instance = DAC1;
    
    HAL_DAC_Init(&dac_ch1_handle);
    HAL_DAC_Init(&dac_ch2_handle);
    
    HAL_DAC_Start(&dac_ch1_handle, DAC_DMA_CH1);
    HAL_DAC_Start(&dac_ch2_handle, DAC_DMA_CH2);
}

/**
 * @brief   ����DAC�����ѹ
* @param   ch: ͨ��; value: DAC��ֵ 0-0xFFF
 * @retval  ��
 */
void dac_set_value(uint8_t ch,uint16_t value)
{
	if(ch==1)
		HAL_DAC_SetValue(&dac_ch1_handle, DAC_DMA_CH1, DAC_ALIGN_12B_R, value);
	else if(ch==2)
		HAL_DAC_SetValue(&dac_ch2_handle, DAC_DMA_CH2, DAC_ALIGN_12B_R, value);
}

void dac_set_ch1_voltage(uint16_t voltage)
{
    uint16_t value;
    
    value = (voltage * 4095) / 3300;
    value &= 0xFFF;
    HAL_DAC_SetValue(&dac_ch1_handle, DAC_DMA_CH1, DAC_ALIGN_12B_R, value);
}


void dac_set_ch2_voltage(uint16_t voltage)
{
    uint16_t value;
    
    value = (voltage * 4095) / 3300;
    value &= 0xFFF;
    HAL_DAC_SetValue(&dac_ch2_handle, DAC_DMA_CH2, DAC_ALIGN_12B_R, value);
}

/**
 * @brief   ����DAC������ǲ�
 * @param   max_value: ���ǲ������ѹ������
 * @param   interval: ÿ���������ʱ��������λ��΢��
 * @param   samples: һ�����ǲ����ڲ�����ĸ���
 * @param   number: ������ǲ��ĸ���
 * @retval  ��
 */
void dac_triangular_wave(uint16_t max_value, uint16_t interval, uint16_t samples, uint16_t number)
{
    uint16_t incval;
    uint16_t curval;
    uint16_t sample_index;
    uint16_t wave_index;
    
    /* ȷ�����������Ϊż�� */
    samples = ((samples + 1) >> 1) << 1;
    /* ����ÿ��������Ĳ���ֵ */
    incval = max_value / (samples >> 1);
    if (incval == 0)
    {
        return;
    }
    
    for (wave_index=0; wave_index<number; wave_index++)
    {
        curval = 0;
        HAL_DAC_SetValue(&dac_ch1_handle, DAC_DMA_CH1, DAC_ALIGN_12B_R, curval);
        
        /* ��������� */
        for (sample_index=0; sample_index<(samples >> 1); sample_index++)
        {
            curval += incval;
            HAL_DAC_SetValue(&dac_ch1_handle, DAC_DMA_CH1, DAC_ALIGN_12B_R, curval);
            delay_us(interval);
        }
        
        /* ����½��� */
        for (sample_index=0; sample_index<(samples >> 1); sample_index++)
        {
            curval -= incval;
            HAL_DAC_SetValue(&dac_ch1_handle, DAC_DMA_CH1, DAC_ALIGN_12B_R, curval);
            delay_us(interval);
        }
    }
}

/**
 * @brief   ��ʼ��DAC DMA�������
 * @param   ��
 * @retval  ��
 */
void dac_dma_wave_init(void)
{
    GPIO_InitTypeDef gpio_init_struct = {0};
    DAC_ChannelConfTypeDef dac_channel_conf_struct = {0};
    TIM_MasterConfigTypeDef tim_master_config_struct = {0};
    
    /* ʹ��ʱ�� */

    DAC_DMA_DACX_TIMX_CLK_ENABLE();
    __HAL_RCC_DAC12_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_DMA1_CLK_ENABLE();

    /**DAC1 GPIO Configuration
    PA5     ------> DAC1_OUT2
    PA4     ------> DAC1_OUT1
    */    
    /* ����DAC������� */
    gpio_init_struct.Pin = DAC_DMA_PIN1;
    gpio_init_struct.Mode = GPIO_MODE_ANALOG;
    HAL_GPIO_Init(DAC_DMA_PORT1, &gpio_init_struct);
 
    gpio_init_struct.Pin = DAC_DMA_PIN2;
    HAL_GPIO_Init(DAC_DMA_PORT2, &gpio_init_struct);
        
    /* ����DMA */
    dma_dac_ch1_handle.Instance = DAC_DMA_CH1_STREAM;
    dma_dac_ch1_handle.Init.Request = DAC_DMA_CH1_REQ;
    dma_dac_ch1_handle.Init.Direction = DMA_MEMORY_TO_PERIPH;
    dma_dac_ch1_handle.Init.PeriphInc = DMA_PINC_DISABLE;
    dma_dac_ch1_handle.Init.MemInc = DMA_MINC_ENABLE;
    dma_dac_ch1_handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    dma_dac_ch1_handle.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    dma_dac_ch1_handle.Init.Mode = DMA_CIRCULAR;
    dma_dac_ch1_handle.Init.Priority = DMA_PRIORITY_VERY_HIGH;
    dma_dac_ch1_handle.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    dma_dac_ch1_handle.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_1QUARTERFULL;
    dma_dac_ch1_handle.Init.MemBurst = DMA_MBURST_SINGLE;
    dma_dac_ch1_handle.Init.PeriphBurst = DMA_PBURST_SINGLE;
    HAL_DMA_Init(&dma_dac_ch1_handle);
    
    dma_dac_ch2_handle.Instance = DAC_DMA_CH2_STREAM;
    dma_dac_ch2_handle.Init.Request = DAC_DMA_CH2_REQ;
    dma_dac_ch2_handle.Init.Direction = DMA_MEMORY_TO_PERIPH;
    dma_dac_ch2_handle.Init.PeriphInc = DMA_PINC_DISABLE;
    dma_dac_ch2_handle.Init.MemInc = DMA_MINC_ENABLE;
    dma_dac_ch2_handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    dma_dac_ch2_handle.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    dma_dac_ch2_handle.Init.Mode = DMA_CIRCULAR;
    dma_dac_ch2_handle.Init.Priority = DMA_PRIORITY_VERY_HIGH;
    dma_dac_ch2_handle.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    dma_dac_ch2_handle.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_1QUARTERFULL;
    dma_dac_ch2_handle.Init.MemBurst = DMA_MBURST_SINGLE;
    dma_dac_ch2_handle.Init.PeriphBurst = DMA_PBURST_SINGLE;
    HAL_DMA_Init(&dma_dac_ch2_handle);
        
    HAL_NVIC_SetPriority(DAC_DMA_CH1_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(DAC_DMA_CH1_IRQn);

    HAL_NVIC_SetPriority(DAC_DMA_CH2_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(DAC_DMA_CH2_IRQn);
    
    __HAL_LINKDMA(&dac_ch1_dma_handle, DMA_Handle1, dma_dac_ch1_handle);
    __HAL_LINKDMA(&dac_ch2_dma_handle, DMA_Handle2, dma_dac_ch2_handle);
    
    /* ���ô�����ʱ�� */
    dac_dma_tim_handle.Instance = DAC_DMA_DACX_TIMX;
    HAL_TIM_Base_Init(&dac_dma_tim_handle);
    tim_master_config_struct.MasterOutputTrigger = TIM_TRGO_UPDATE;
    HAL_TIMEx_MasterConfigSynchronization(&dac_dma_tim_handle, &tim_master_config_struct);
    
    /* ����DAC */
    dac_ch1_dma_handle.Instance = DAC1;
    HAL_DAC_Init(&dac_ch1_dma_handle);
 
    dac_ch2_dma_handle.Instance = DAC1;
    HAL_DAC_Init(&dac_ch2_dma_handle);
    
    /* ����DACͨ�� */
    dac_channel_conf_struct.DAC_SampleAndHold = DAC_SAMPLEANDHOLD_DISABLE;                  /* ģʽ */
    dac_channel_conf_struct.DAC_Trigger = DAC_TRIGGER_T7_TRGO;                              /* ����Դ */
    dac_channel_conf_struct.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;                     /* ������� */
    dac_channel_conf_struct.DAC_ConnectOnChipPeripheral = DAC_CHIPCONNECT_EXTERNAL;         /* �����Ƭ������ */
    dac_channel_conf_struct.DAC_UserTrimming = DAC_TRIMMING_FACTORY;                        /* ΢�� */
    dac_channel_conf_struct.DAC_TrimmingValue = 1;                                          /* ΢��ֵ */
    dac_channel_conf_struct.DAC_SampleAndHoldConfig.DAC_SampleTime = 0;                     /* �����ͱ���ģʽ�µĲ���ʱ�� */
    dac_channel_conf_struct.DAC_SampleAndHoldConfig.DAC_HoldTime = 0;                       /* �����ͱ���ģʽ�µı���ʱ�� */
    dac_channel_conf_struct.DAC_SampleAndHoldConfig.DAC_RefreshTime = 0;                    /* �����ͱ���ģʽ�µ�ˢ��ʱ�� */
    HAL_DAC_ConfigChannel(&dac_ch1_dma_handle, &dac_channel_conf_struct, DAC_DMA_CH1);
    HAL_DAC_ConfigChannel(&dac_ch2_dma_handle, &dac_channel_conf_struct, DAC_DMA_CH2);
}

/**
 * @brief   DMA�жϷ�����
 * @param   ��
 * @retval  ��
 */
void DAC_DMA_DACX_DMASX_IRQHandler(void)
{
    HAL_DMA_IRQHandler(&dma_dac_ch1_handle);
}

#if 0
/**
 * @brief   ʹ��DAC DMA�������
 * @param   ndtr: DMA����������һ�����������Ŀ
 * @param   arr: DAC������ʱ�����Զ���װ��ֵ
 * @param   psc: DAC������ʱ����Ԥ��Ƶ����ֵ
 * @retval  ��
 */
void dac_dma_wave_enable(uint16_t ndtr, uint16_t arr, uint16_t psc)
{
    /* ����TIM */
    dac_dma_tim_handle.Init.Prescaler = psc;
    dac_dma_tim_handle.Init.Period = arr;
    dac_dma_tim_handle.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
    HAL_TIM_Base_Init(&dac_dma_tim_handle);
    HAL_TIM_Base_Start(&dac_dma_tim_handle);
    
    /* ���¿���DAC DMA���� */
    HAL_DAC_Stop_DMA(&dac_ch1_dma_handle, DAC_DMA_CH1);
    HAL_DAC_Start_DMA(&dac_ch1_dma_handle, DAC_DMA_CH1, (uint32_t *)g_dac_sin_buf, ndtr, DAC_ALIGN_12B_R);
    
    HAL_DAC_Stop_DMA(&dac_ch2_dma_handle, DAC_DMA_CH2);
    HAL_DAC_Start_DMA(&dac_ch2_dma_handle, DAC_DMA_CH2, (uint32_t *)g_dac_sin_buf, ndtr, DAC_ALIGN_12B_R);
}





/**
 * @brief   ������������
 * @param   maxval: ���ҵ����
 * @param   samples: ����һ�����ڵĲ��������
 * @retval  ��
 */
static void dac_creat_sin_buf(uint16_t maxval, uint16_t samples)
{
    uint16_t i;
    double w;
    uint16_t outdata;
    
    w = (2 * 3.1415926) / samples;                  /* ��=2��/T */
    
    for (i=0; i<samples; i++)
    {
        outdata = maxval * sin(w * i + 0) + maxval; /* y=Asin(��x+��)+b */
        if (outdata > 4095)                         /* �������� */
        {
            outdata = 4095;
        }
        g_dac_sin_buf[i] = outdata;
    }
}

#endif
