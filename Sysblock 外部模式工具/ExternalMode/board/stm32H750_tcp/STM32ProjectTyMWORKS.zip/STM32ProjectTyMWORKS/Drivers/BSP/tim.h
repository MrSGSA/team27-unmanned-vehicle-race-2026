#ifndef __TIM_H__
#define __TIM_H__

#include "./SYSTEM/sys/sys.h"


#define TIM1_MOTOR_ARR		12000//12000	//10K
#define TIM1_MOTOR_PSC		(1-1)		
#define TIM1_MOTOR_PULSE	(0)		//ռ�ձ�

#define PI                     (3.1415926f) // ��  
#define SIN_AMPMAX             255 // ��׼�������ߵķ�ֵ

extern TIM_HandleTypeDef g_timx_encode_chy_handle;         /* ��ʱ��x��� */

/**TIM1 GPIO Configuration
PA10     ------> TIM1_CH3
PA9     ------> TIM1_CH2
PA8     ------> TIM1_CH1
PB15     ------> TIM1_CH3N
PB13     ------> TIM1_CH1N
PB14     ------> TIM1_CH2N
*/
    
#define TIM1_CH1_N              TIM_CHANNEL_1
#define TIM1_CH1_GPIO_PORT      GPIOA
#define TIM1_CH1_GPIO_PIN       GPIO_PIN_8
#define TIM1_CH1_GPIO_AF        GPIO_AF1_TIM1

#define TIM1_CH2_N              TIM_CHANNEL_2
#define TIM1_CH2_GPIO_PORT      GPIOA
#define TIM1_CH2_GPIO_PIN       GPIO_PIN_9
#define TIM1_CH2_GPIO_AF        GPIO_AF1_TIM1

#define TIM1_CH3_N              TIM_CHANNEL_3
#define TIM1_CH3_GPIO_PORT      GPIOA
#define TIM1_CH3_GPIO_PIN       GPIO_PIN_10
#define TIM1_CH3_GPIO_AF        GPIO_AF1_TIM1

#define TIM1_CH1N_GPIO_PORT      GPIOB
#define TIM1_CH1N_GPIO_PIN       GPIO_PIN_13
#define TIM1_CH1N_GPIO_AF        GPIO_AF1_TIM1

#define TIM1_CH2N_GPIO_PORT      GPIOB
#define TIM1_CH2N_GPIO_PIN       GPIO_PIN_14
#define TIM1_CH2N_GPIO_AF        GPIO_AF1_TIM1

#define TIM1_CH3N_GPIO_PORT      GPIOB
#define TIM1_CH3N_GPIO_PIN       GPIO_PIN_15
#define TIM1_CH3N_GPIO_AF        GPIO_AF1_TIM1

/**TIM8 GPIO Configuration
PI6     ------> TIM8_CH2
PI5     ------> TIM8_CH1
PI7     ------> TIM8_CH3
PH15     ------> TIM8_CH3N
PH14     ------> TIM8_CH2N
PH13     ------> TIM8_CH1N
*/
//#define TIM8_CH1_N              TIM_CHANNEL_1
//#define TIM8_CH1_GPIO_PORT      GPIOI
//#define TIM8_CH1_GPIO_PIN       GPIO_PIN_5
//#define TIM8_CH1_GPIO_AF        GPIO_AF3_TIM8

#define TIM8_CH2_N              TIM_CHANNEL_2
#define TIM8_CH2_GPIO_PORT      GPIOI
#define TIM8_CH2_GPIO_PIN       GPIO_PIN_6
#define TIM8_CH2_GPIO_AF        GPIO_AF3_TIM8

#define TIM8_CH3_N              TIM_CHANNEL_3
#define TIM8_CH3_GPIO_PORT      GPIOI
#define TIM8_CH3_GPIO_PIN       GPIO_PIN_7
#define TIM8_CH3_GPIO_AF        GPIO_AF3_TIM8

#define TIM8_CH1N_GPIO_PORT      GPIOH
#define TIM8_CH1N_GPIO_PIN       GPIO_PIN_13
#define TIM8_CH1N_GPIO_AF        GPIO_AF3_TIM8

#define TIM8_CH2N_GPIO_PORT      GPIOH
#define TIM8_CH2N_GPIO_PIN       GPIO_PIN_14
#define TIM8_CH2N_GPIO_AF        GPIO_AF3_TIM8

#define TIM8_CH3N_GPIO_PORT      GPIOH
#define TIM8_CH3N_GPIO_PIN       GPIO_PIN_15
#define TIM8_CH3N_GPIO_AF        GPIO_AF3_TIM8


#define MODE_SINGLE_PHASE       1   //����
#define MODE_THREE_PHASE        0   //����

/*
PB3     ------> TIM2_CH2
PC9     ------> TIM3_CH4
PB6     ------> TIM4_CH1
PI0     ------> TIM5_CH4
PH6     ------> TIM12_CH1
PE6     ------> TIM15_CH2
*/
#define TIM_PWM1_T                  TIM4
#define TIM_PWM1_CLK_ENABLE()       do { __HAL_RCC_TIM4_CLK_ENABLE(); } while (0)
#define TIM_PWM1_CH                 TIM_CHANNEL_1
#define TIM_PWM1_PORT               GPIOB
#define TIM_PWM1_PIN                GPIO_PIN_6
#define TIM_PWM1_AF                 GPIO_AF2_TIM4
#define TIM_PWM1_GPIO_CLK_ENABLE()  do { __HAL_RCC_GPIOB_CLK_ENABLE(); } while (0)

#define TIM_PWM2_T                  TIM2
#define TIM_PWM2_CLK_ENABLE()       do { __HAL_RCC_TIM2_CLK_ENABLE(); } while (0)
#define TIM_PWM2_CH                 TIM_CHANNEL_2
#define TIM_PWM2_PORT               GPIOB
#define TIM_PWM2_PIN                GPIO_PIN_3
#define TIM_PWM2_AF                 GPIO_AF1_TIM2
#define TIM_PWM2_GPIO_CLK_ENABLE()  do { __HAL_RCC_GPIOB_CLK_ENABLE(); } while (0)

#define TIM_PWM3_T                  TIM5
#define TIM_PWM3_CLK_ENABLE()       do { __HAL_RCC_TIM5_CLK_ENABLE(); } while (0)
#define TIM_PWM3_CH                 TIM_CHANNEL_4
#define TIM_PWM3_PORT               GPIOI
#define TIM_PWM3_PIN                GPIO_PIN_0
#define TIM_PWM3_AF                 GPIO_AF2_TIM5
#define TIM_PWM3_GPIO_CLK_ENABLE()  do { __HAL_RCC_GPIOI_CLK_ENABLE(); } while (0)

#define TIM_PWM4_T                  TIM3
#define TIM_PWM4_CLK_ENABLE()       do { __HAL_RCC_TIM3_CLK_ENABLE(); } while (0)
#define TIM_PWM4_CH                 TIM_CHANNEL_4
#define TIM_PWM4_PORT               GPIOC
#define TIM_PWM4_PIN                GPIO_PIN_9
#define TIM_PWM4_AF                 GPIO_AF2_TIM3
#define TIM_PWM4_GPIO_CLK_ENABLE()  do { __HAL_RCC_GPIOC_CLK_ENABLE(); } while (0)

#define TIM_PWM5_T                  TIM12
#define TIM_PWM5_CLK_ENABLE()       do { __HAL_RCC_TIM12_CLK_ENABLE(); } while (0)
#define TIM_PWM5_CH                 TIM_CHANNEL_1
#define TIM_PWM5_PORT               GPIOH
#define TIM_PWM5_PIN                GPIO_PIN_6
#define TIM_PWM5_AF                 GPIO_AF2_TIM12
#define TIM_PWM5_GPIO_CLK_ENABLE()  do { __HAL_RCC_GPIOH_CLK_ENABLE(); } while (0)

#define TIM_PWM6_T                  TIM15
#define TIM_PWM6_CLK_ENABLE()       do { __HAL_RCC_TIM15_CLK_ENABLE(); } while (0)
#define TIM_PWM6_CH                 TIM_CHANNEL_2
#define TIM_PWM6_PORT               GPIOE
#define TIM_PWM6_PIN                GPIO_PIN_6
#define TIM_PWM6_AF                 GPIO_AF2_TIM15
#define TIM_PWM6_GPIO_CLK_ENABLE()  do { __HAL_RCC_GPIOE_CLK_ENABLE(); } while (0)

    /**TIM3 GPIO Configuration
    PC8     ------> TIM3_CH3
    PC9     ------> TIM3_CH4
    PC7     ------> TIM3_CH2
    PC6     ------> TIM3_CH1
    */

#define GTIM_TIMX_INT                       TIM17
#define GTIM_TIMX_INT_IRQn                  TIM17_IRQn
#define GTIM_TIMX_INT_IRQHandler            TIM17_IRQHandler
#define GTIM_TIMX_INT_CLK_ENABLE()          do { __HAL_RCC_TIM17_CLK_ENABLE(); } while (0)


/* ͨ�ö�ʱ�� ����  */
#define GTIM_TIMX_ENCODER_CH1_GPIO_PORT         GPIOC
#define GTIM_TIMX_ENCODER_CH1_GPIO_PIN          GPIO_PIN_6
#define GTIM_TIMX_ENCODER_CH1_GPIO_CLK_ENABLE() do{ __HAL_RCC_GPIOC_CLK_ENABLE(); }while(0)  /* PC��ʱ��ʹ�� */

#define GTIM_TIMX_ENCODER_CH2_GPIO_PORT         GPIOC
#define GTIM_TIMX_ENCODER_CH2_GPIO_PIN          GPIO_PIN_7
#define GTIM_TIMX_ENCODER_CH2_GPIO_CLK_ENABLE() do{ __HAL_RCC_GPIOC_CLK_ENABLE(); }while(0)  /* PC��ʱ��ʹ�� */

/* TIMX ���Ÿ�������
 * ��ΪPC6/PC7, Ĭ�ϲ�����TIM3�Ĺ��ܽ�, ���뿪������, �ſ�������TIM3��CH1/CH2����
 */
#define GTIM_TIMX_ENCODERCH1_GPIO_AF            GPIO_AF2_TIM3                                /* �˿ڸ��õ�TIM3 */
#define GTIM_TIMX_ENCODERCH2_GPIO_AF            GPIO_AF2_TIM3                                /* �˿ڸ��õ�TIM3 */

#define GTIM_TIMX_ENCODER                       TIM3                                         /* TIM3 */
#define GTIM_TIMX_ENCODER_INT_IRQn              TIM3_IRQn
#define GTIM_TIMX_ENCODER_INT_IRQHandler        TIM3_IRQHandler

#define GTIM_TIMX_ENCODER_CH1                   TIM_CHANNEL_1                                /* ͨ��1 */
#define GTIM_TIMX_ENCODER_CH1_CLK_ENABLE()      do{ __HAL_RCC_TIM3_CLK_ENABLE(); }while(0)   /* TIM3 ʱ��ʹ�� */

#define GTIM_TIMX_ENCODER_CH2                   TIM_CHANNEL_2                                /* ͨ��2 */
#define GTIM_TIMX_ENCODER_CH2_CLK_ENABLE()      do{ __HAL_RCC_TIM3_CLK_ENABLE(); }while(0)   /* TIM3 ʱ��ʹ�� */


//#define ROTO_RATIO      10000  // ���� 2500*4
#define ENC_TMS			100		//ms


#define _sqrt3_2        0.8660254037844f
#define _1_2			0.5f
#define Ts				1

/* �����������ṹ�� */
typedef struct 
{
  int encode_old;                  /* ��һ�μ���ֵ */
  int encode_now;                  /* ��ǰ����ֵ */
  int speed;                     /* �������ٶ� */
} ENCODE_TypeDef;

extern ENCODE_TypeDef g_encode;    /* �������������� */
extern int16_t pmsm_speed; 
extern uint8_t encoder_speed[10];

extern uint8_t encode_en;	//����������ʹ��
extern uint8_t encode_tms;	//�������������� ms
extern uint8_t speed_flag;

typedef struct
{
    TIM_HandleTypeDef *handle;
    uint32_t channel;
    uint16_t arr;
    uint16_t psc;
    uint16_t ccr;  
}PWM_TypeDef;  
extern PWM_TypeDef pwm_out[6];

/*�߼���ʱ�������������������*/
typedef struct
{
    TIM_HandleTypeDef *handle;
    TIM_BreakDeadTimeConfigTypeDef *dead;   /* �������Ʋ������þ�� */
    uint16_t arr;
    uint16_t psc;
    uint16_t ccr; 
    uint8_t dtg;    //����ʱ��
    uint8_t mode;
}PWM_CPLM_TypeDef;  

extern PWM_CPLM_TypeDef tim1_pwm_out;
extern PWM_CPLM_TypeDef tim8_pwm_out;

extern uint8_t gtim_flag;
extern TIM_HandleTypeDef t1_handle;

extern float Ta;
extern float Tb;
extern float Tc;

void tim_pwm_cplm_init(void);
void tim_pwm_init(void);

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

void pwm_set_arr(PWM_TypeDef *p);
void pwm_set_ccr(PWM_TypeDef *p);

void tim_init(void);

void tim1_gpio_init(uint8_t mode);
uint32_t hallsensor_get_state(uint8_t motor_id);
void t17_init(uint16_t arr, uint16_t psc);

void tim1_three_pwm_init(uint16_t arr, uint16_t psc,uint8_t mode,uint8_t dtg);
void tim1_set_compare(uint16_t ccr1,uint16_t ccr2,uint16_t ccr3);
void t1_motor_start(void);
void t1_motor_stop(void);

void tim8_three_pwm_init(uint16_t arr, uint16_t psc,uint8_t mode,uint8_t dtg);
void tim8_set_compare(uint16_t ccr1,uint16_t ccr2,uint16_t ccr3);
void t8_motor_start(void);
void t8_motor_stop(void);

int gtim_get_encode(void);

void encoder_start(void);
void encoder_stop(void);


#endif /* __TIM_H__ */