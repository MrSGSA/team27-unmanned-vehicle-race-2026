#ifndef __DAC_H
#define __DAC_H

#include "./SYSTEM/sys/sys.h"

/* DAC���� */
#define DAC1_DMA            DAC1

#define DAC_DMA_CH1         DAC_CHANNEL_1
#define DAC_DMA_PORT1       GPIOA
#define DAC_DMA_PIN1        GPIO_PIN_4

#define DAC_DMA_CH2         DAC_CHANNEL_2
#define DAC_DMA_PORT2       GPIOA
#define DAC_DMA_PIN2        GPIO_PIN_5


#define DAC_DMA_CH1_STREAM        DMA1_Stream3
#define DAC_DMA_CH1_REQ           DMA_REQUEST_DAC1_CH1
#define DAC_DMA_CH1_IRQn          DMA1_Stream3_IRQn
#define DAC_DMA_CH1_IRQHandler    DMA1_Stream3_IRQHandler

#define DAC_DMA_CH2_STREAM        DMA1_Stream4
#define DAC_DMA_CH2_REQ           DMA_REQUEST_DAC1_CH2
#define DAC_DMA_CH2_IRQn          DMA1_Stream4_IRQn
#define DAC_DMA_CH2_IRQHandler    DMA1_Stream4_IRQHandler

#define DAC_DMA_DACX_TIMX                   TIM7
#define DAC_DMA_DACX_TIMX_CLK_ENABLE()      do { __HAL_RCC_TIM7_CLK_ENABLE(); } while (0)

/* �������� */
void dac_init(void);   	  /* ��ʼ��DAC */
void dac_set_value(uint8_t ch,uint16_t value); 
void dac_set_ch1_voltage(uint16_t voltage);       
void dac_set_ch2_voltage(uint16_t voltage);   /* ����DAC�����ѹ */
void dac_triangular_wave(uint16_t max_value, uint16_t interval, uint16_t samples, uint16_t number); /* ����DAC������ǲ� */
void dac_dma_wave_init(void);                                           /* ��ʼ��DAC DMA������� */
void dac_dma_wave_enable(uint16_t ndtr, uint16_t arr, uint16_t psc);    /* ʹ��DAC DMA������� */

#endif
