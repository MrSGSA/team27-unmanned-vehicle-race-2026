#include "./BSP/ADC/adc.h"
#include "./SYSTEM/usart/usart.h"
#include "comm.h"

/* ADC��� */
//ADC_HandleTypeDef g_adc_handle = {0};
//ADC_HandleTypeDef g_adc_dma_handle = {0};
ADC_HandleTypeDef adc1_handle = {0};
ADC_HandleTypeDef adc2_handle = {0};
ADC_HandleTypeDef adc3_handle = {0};

/* ��ͨ��ADC�ɼ���DMA��ȡ����ر��� */
//DMA_HandleTypeDef g_adc_dma_dma_handle = {0};
//uint8_t g_adc_dma_sta = 0;
//uint32_t g_adc_dma_memory_base;

/* ��ͨ��ADC�ɼ���DMA��ȡ����ر��� */
DMA_HandleTypeDef dma_adc1_handle = {0};
DMA_HandleTypeDef dma_adc2_handle = {0};
DMA_HandleTypeDef dma_adc3_handle = {0};

uint8_t adc1_dma_sta = 0;
uint8_t adc2_dma_sta = 0;
uint8_t adc3_dma_sta = 0;


__IO uint16_t adc1_dma_buf[ADC1_DMA_BUF_SIZE];
__IO uint16_t adc2_dma_buf[ADC2_DMA_BUF_SIZE];
__IO uint16_t adc3_dma_buf[ADC3_DMA_BUF_SIZE];

#if 0
/**
 * @brief   ��ʼ��ADC
 * @param   ��
 * @retval  ��
 */
void adc_init(void)
{
    GPIO_InitTypeDef gpio_init_struct = {0};
    
    /* ����ʱ�� */
    rcc_periph_clk_init_struct.PeriphClockSelection |= RCC_PERIPHCLK_ADC;
    rcc_periph_clk_init_struct.AdcClockSelection = RCC_ADCCLKSOURCE_PLL2;
    HAL_RCCEx_PeriphCLKConfig(&rcc_periph_clk_init_struct);
    
    /* ʹ��ʱ�� */
    ADC_ADCX_CLK_ENABLE();
    ADC_ADCX_CHY_GPIO_CLK_ENABLE();
    
    /* ѡ��ʱ��Դ */
    __HAL_RCC_ADC_CONFIG(RCC_ADCCLKSOURCE_CLKP);
    
    /* ����ADC�������� */
    gpio_init_struct.Pin = ADC_ADCX_CHY_GPIO_PIN;
    gpio_init_struct.Mode = GPIO_MODE_ANALOG;
    HAL_GPIO_Init(ADC_ADCX_CHY_GPIO_PORT, &gpio_init_struct);
    
    /* ����ADC */
    g_adc_handle.Instance = ADC_ADCX;
    g_adc_handle.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;                                    /* ʱ��Դ��ʱ��Ԥ��Ƶϵ�� */
    g_adc_handle.Init.Resolution = ADC_RESOLUTION_16B;                                          /* �ֱ��� */
    g_adc_handle.Init.ScanConvMode = ADC_SCAN_DISABLE;                                          /* ɨ��ת��ģʽ */
    g_adc_handle.Init.EOCSelection = ADC_EOC_SINGLE_CONV;                                       /* ת������������Flag */
    g_adc_handle.Init.LowPowerAutoWait = DISABLE;                                               /* �Զ��ӳ�ת�� */
    g_adc_handle.Init.ContinuousConvMode = DISABLE;                                             /* ����ת��ģʽ */
    g_adc_handle.Init.NbrOfConversion = 1;                                                      /* ɨ��ת��ģʽ�µ�Rank���� */
    g_adc_handle.Init.DiscontinuousConvMode = DISABLE;                                          /* ɨ��ת��ģʽ�µļ��ת��ģʽ */
    g_adc_handle.Init.NbrOfDiscConversion = 1;                                                  /* ���ת��ģʽ��һ��ת����Rank���� */
    g_adc_handle.Init.ExternalTrigConv = ADC_SOFTWARE_START;                                    /* ת���ⲿ����Դ */
    g_adc_handle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;                     /* ת���ⲿ����Դ����Ч�� */
    g_adc_handle.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DR;                         /* ת�����ݹ��� */
    g_adc_handle.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;                                       /* ת�����������д */
    g_adc_handle.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;                                     /* ת���������� */
    g_adc_handle.Init.OversamplingMode = DISABLE;                                               /* ������ģʽ */
    g_adc_handle.Init.Oversampling.Ratio = 0;                                                   /* �������� */
    g_adc_handle.Init.Oversampling.RightBitShift = ADC_RIGHTBITSHIFT_NONE;                      /* ���������� */
    g_adc_handle.Init.Oversampling.TriggeredMode = ADC_TRIGGEREDMODE_SINGLE_TRIGGER;            /* ����������ģʽ */
    g_adc_handle.Init.Oversampling.OversamplingStopReset = ADC_REGOVERSAMPLING_CONTINUED_MODE;  /* ���������ģʽ */
    HAL_ADC_Init(&g_adc_handle);
    
    /* ADC�Զ���У׼ */
    HAL_ADCEx_Calibration_Start(&g_adc_handle, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED);
}

/**
 * @brief   ��ȡADC���
 * @param   channel: ADCͨ��
 * @retval  ADC���
 */
uint32_t adc_get_result(uint32_t channel)
{
    ADC_ChannelConfTypeDef adc_channel_conf_struct = {0};
    uint32_t result;
    
    /* ����ADCͨ�� */
    adc_channel_conf_struct.Channel = channel;                          /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_1;                  /* Rank��� */
    adc_channel_conf_struct.SamplingTime = ADC_SAMPLETIME_810CYCLES_5;  /* ����ʱ�� */
    adc_channel_conf_struct.SingleDiff = ADC_SINGLE_ENDED;              /* ��������ģʽ */
    adc_channel_conf_struct.OffsetNumber = ADC_OFFSET_NONE;             /* ƫ�� */
    adc_channel_conf_struct.Offset = 0;                                 /* ƫ���� */
    adc_channel_conf_struct.OffsetRightShift = DISABLE;                 /* ƫ�ƺ����� */
    adc_channel_conf_struct.OffsetSignedSaturation = DISABLE;           /* ���ű��� */
    HAL_ADC_ConfigChannel(&g_adc_handle, &adc_channel_conf_struct);
    
    HAL_ADC_Start(&g_adc_handle);                                       /* ����ADCת�� */
    HAL_ADC_PollForConversion(&g_adc_handle, HAL_MAX_DELAY);            /* �ȴ�ADCת������ */
    result = HAL_ADC_GetValue(&g_adc_handle);                           /* ��ȡADCת����� */
    HAL_ADC_Stop(&g_adc_handle);                                        /* ֹͣADCת�� */
    
    return result;
}

/**
 * @brief   ��ֵ�˲���ȡADC���
 * @param   channel: ADCͨ��
 * @param   times: ��ֵ�˲���ԭʼ���ݸ���
 * @retval  ADC���
 */
uint32_t adc_get_result_average(uint32_t channel, uint8_t times)
{
    uint32_t sum_result = 0;
    uint8_t index;
    uint32_t result;
    
    for (index=0; index<times; index++)
    {
        sum_result += adc_get_result(channel);
    }
    
    result = sum_result / times;
    
    return result;
}

/**
 * @brief   ��ʼ��ADC DMA��ȡ
 * @param   memory_base: ��ȡĿ���ڴ����ַ
 * @retval  ��
 */
void adc_dma_init(uint32_t memory_base)
{
    GPIO_InitTypeDef gpio_init_struct = {0};
    
    /* ����ʱ�� */
    rcc_periph_clk_init_struct.PeriphClockSelection |= RCC_PERIPHCLK_ADC;
    rcc_periph_clk_init_struct.AdcClockSelection = RCC_ADCCLKSOURCE_PLL2;
    HAL_RCCEx_PeriphCLKConfig(&rcc_periph_clk_init_struct);
    
    /* ʹ��ʱ�� */
    ADC_DMA_ADCX_CLK_ENABLE();
    ADC_DMA_ADCX_CHY_GPIO_CLK_ENABLE();
    ADC_DMA_ADCX_DMA_CLK_ENABLE();
    
    /* ѡ��ʱ��Դ */
    __HAL_RCC_ADC_CONFIG(RCC_ADCCLKSOURCE_CLKP);
    
    /* ����ADC�������� */
    gpio_init_struct.Pin = ADC_DMA_ADCX_CHY_GPIO_PIN;
    gpio_init_struct.Mode = GPIO_MODE_ANALOG;
    HAL_GPIO_Init(ADC_DMA_ADCX_CHY_GPIO_PORT, &gpio_init_struct);
    
    /* ����DMA */
    g_adc_dma_dma_handle.Instance = ADC_DMA_ADCX_DMASX;
    g_adc_dma_dma_handle.Init.Request = ADC_DMA_ADCX_DMASX_REQ;
    g_adc_dma_dma_handle.Init.Direction = DMA_PERIPH_TO_MEMORY;
    g_adc_dma_dma_handle.Init.PeriphInc = DMA_PINC_DISABLE;
    g_adc_dma_dma_handle.Init.MemInc = DMA_MINC_ENABLE;
    g_adc_dma_dma_handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    g_adc_dma_dma_handle.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    g_adc_dma_dma_handle.Init.Mode = DMA_NORMAL;
    g_adc_dma_dma_handle.Init.Priority = DMA_PRIORITY_VERY_HIGH;
    g_adc_dma_dma_handle.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    g_adc_dma_dma_handle.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_1QUARTERFULL;
    g_adc_dma_dma_handle.Init.MemBurst = DMA_MBURST_SINGLE;
    g_adc_dma_dma_handle.Init.PeriphBurst = DMA_PBURST_SINGLE;
    HAL_DMA_Init(&g_adc_dma_dma_handle);
    HAL_NVIC_SetPriority(ADC_DMA_ADCX_DMASX_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(ADC_DMA_ADCX_DMASX_IRQn);
    
    __HAL_LINKDMA(&g_adc_dma_handle, DMA_Handle, g_adc_dma_dma_handle);
    
    /* ����ADC */
    g_adc_dma_handle.Instance = ADC_DMA_ADCX;
    g_adc_dma_handle.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;                                    /* ʱ��Դ��ʱ��Ԥ��Ƶϵ�� */
    g_adc_dma_handle.Init.Resolution = ADC_RESOLUTION_16B;                                          /* �ֱ��� */
    g_adc_dma_handle.Init.ScanConvMode = ADC_SCAN_DISABLE;                                          /* ɨ��ת��ģʽ */
    g_adc_dma_handle.Init.EOCSelection = ADC_EOC_SINGLE_CONV;                                       /* ת������������Flag */
    g_adc_dma_handle.Init.LowPowerAutoWait = DISABLE;                                               /* �Զ��ӳ�ת�� */
    g_adc_dma_handle.Init.ContinuousConvMode = ENABLE;                                              /* ����ת��ģʽ */
    g_adc_dma_handle.Init.NbrOfConversion = 1;                                                      /* ɨ��ת��ģʽ�µ�Rank���� */
    g_adc_dma_handle.Init.DiscontinuousConvMode = DISABLE;                                          /* ɨ��ת��ģʽ�µļ��ת��ģʽ */
    g_adc_dma_handle.Init.NbrOfDiscConversion = 1;                                                  /* ���ת��ģʽ��һ��ת����Rank���� */
    g_adc_dma_handle.Init.ExternalTrigConv = ADC_SOFTWARE_START;                                    /* ת���ⲿ����Դ */
    g_adc_dma_handle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;                     /* ת���ⲿ����Դ����Ч�� */
    g_adc_dma_handle.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DMA_ONESHOT;                /* ת�����ݹ��� */
    g_adc_dma_handle.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;                                       /* ת�����������д */
    g_adc_dma_handle.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;                                     /* ת���������� */
    g_adc_dma_handle.Init.OversamplingMode = DISABLE;                                               /* ������ģʽ */
    g_adc_dma_handle.Init.Oversampling.Ratio = 0;                                                   /* �������� */
    g_adc_dma_handle.Init.Oversampling.RightBitShift = ADC_RIGHTBITSHIFT_NONE;                      /* ���������� */
    g_adc_dma_handle.Init.Oversampling.TriggeredMode = ADC_TRIGGEREDMODE_SINGLE_TRIGGER;            /* ����������ģʽ */
    g_adc_dma_handle.Init.Oversampling.OversamplingStopReset = ADC_REGOVERSAMPLING_CONTINUED_MODE;  /* ���������ģʽ */
    HAL_ADC_Init(&g_adc_dma_handle);
    
    /* ADC�Զ���У׼ */
    HAL_ADCEx_Calibration_Start(&g_adc_dma_handle, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED);
    
    g_adc_dma_memory_base = memory_base;
}

/**
 * @brief   ����ADC DMA��ȡ
 * @param   length: DMA��ȡ����
 * @retval  ��
 */
void adc_dma_enable(uint32_t length)
{
    ADC_ChannelConfTypeDef adc_channel_conf_struct = {0};
    
    /* ֹͣADC DMAת�� */
    HAL_ADC_Stop_DMA(&g_adc_dma_handle);
    
    /* ����ADCͨ�� */
    adc_channel_conf_struct.Channel = ADC_DMA_ADCX_CHY;                 /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_1;                  /* Rank��� */
    adc_channel_conf_struct.SamplingTime = ADC_SAMPLETIME_810CYCLES_5;  /* ����ʱ�� */
    adc_channel_conf_struct.SingleDiff = ADC_SINGLE_ENDED;              /* ��������ģʽ */
    adc_channel_conf_struct.OffsetNumber = ADC_OFFSET_NONE;             /* ƫ�� */
    adc_channel_conf_struct.Offset = 0;                                 /* ƫ���� */
    adc_channel_conf_struct.OffsetRightShift = DISABLE;                 /* ƫ�ƺ����� */
    adc_channel_conf_struct.OffsetSignedSaturation = DISABLE;           /* ���ű��� */
    HAL_ADC_ConfigChannel(&g_adc_dma_handle, &adc_channel_conf_struct);
    
    /* ����ADC DMAת�� */
    HAL_ADC_Start_DMA(&g_adc_dma_handle, (uint32_t *)g_adc_dma_memory_base, length);
}

#endif

/**
 * @brief   ��ʼ����ͨ��ADC DMA��ȡ
 * @param   memory_base: ��ȡĿ���ڴ����ַ
 * @retval  ��
 */
void adc_dma_init(void)
{
    GPIO_InitTypeDef gpio_init_struct = {0};
    
    /* ����ʱ�� */
    rcc_periph_clk_init_struct.PeriphClockSelection |= RCC_PERIPHCLK_ADC;
    rcc_periph_clk_init_struct.AdcClockSelection = RCC_ADCCLKSOURCE_PLL2;
    HAL_RCCEx_PeriphCLKConfig(&rcc_periph_clk_init_struct);
    
    /* ʹ��ʱ�� */
    __HAL_RCC_ADC12_CLK_ENABLE();
    __HAL_RCC_ADC3_CLK_ENABLE();
    
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOF_CLK_ENABLE();
    __HAL_RCC_GPIOH_CLK_ENABLE();
    
    __HAL_RCC_DMA1_CLK_ENABLE();
    
    /* ѡ��ʱ��Դ */
    __HAL_RCC_ADC_CONFIG(RCC_ADCCLKSOURCE_CLKP);
    
    gpio_init_struct.Mode = GPIO_MODE_ANALOG;
	gpio_init_struct.Pull = GPIO_PULLDOWN;
    /* ����ADC�������� */
    gpio_init_struct.Pin = ADC1_A2_PIN;
    HAL_GPIO_Init(ADC1_A2_PORT, &gpio_init_struct);

    gpio_init_struct.Pin = ADC1_A3_PIN;
    HAL_GPIO_Init(ADC1_A3_PORT, &gpio_init_struct);

    gpio_init_struct.Pin = ADC1_A4_PIN;    
    HAL_GPIO_Init(ADC1_A4_PORT, &gpio_init_struct);
    
    gpio_init_struct.Pin = ADC2_A2_PIN;
    HAL_GPIO_Init(ADC2_A2_PORT, &gpio_init_struct);

    gpio_init_struct.Pin = ADC2_A3_PIN;
    HAL_GPIO_Init(ADC2_A3_PORT, &gpio_init_struct);
    
    gpio_init_struct.Pin = ADC3_A3_PIN;
    HAL_GPIO_Init(ADC3_A3_PORT, &gpio_init_struct);
    
    gpio_init_struct.Pin = ADC3_A4_PIN;
    HAL_GPIO_Init(ADC3_A4_PORT, &gpio_init_struct);

    gpio_init_struct.Pin = ADC3_A5_PIN;
    HAL_GPIO_Init(ADC3_A5_PORT, &gpio_init_struct);

    gpio_init_struct.Pin = ADC3_A6_PIN;
    HAL_GPIO_Init(ADC3_A6_PORT, &gpio_init_struct);

    gpio_init_struct.Pin = ADC3_A7_PIN;
    HAL_GPIO_Init(ADC3_A7_PORT, &gpio_init_struct);

    gpio_init_struct.Pin = ADC3_A8_PIN;
    HAL_GPIO_Init(ADC3_A8_PORT, &gpio_init_struct);

    gpio_init_struct.Pin = ADC3_A9_PIN;
    HAL_GPIO_Init(ADC3_A9_PORT, &gpio_init_struct);

    gpio_init_struct.Pin = ADC3_A10_PIN;
    HAL_GPIO_Init(ADC3_A10_PORT, &gpio_init_struct);

    gpio_init_struct.Pin = ADC3_A11_PIN;
    HAL_GPIO_Init(ADC3_A11_PORT, &gpio_init_struct);
    
    HAL_SYSCFG_AnalogSwitchConfig(SYSCFG_SWITCH_PA0, SYSCFG_SWITCH_PA0_OPEN);
    HAL_SYSCFG_AnalogSwitchConfig(SYSCFG_SWITCH_PA1, SYSCFG_SWITCH_PA1_OPEN);
    HAL_SYSCFG_AnalogSwitchConfig(SYSCFG_SWITCH_PC2, SYSCFG_SWITCH_PC2_OPEN);
    HAL_SYSCFG_AnalogSwitchConfig(SYSCFG_SWITCH_PC3, SYSCFG_SWITCH_PC3_OPEN);
    
    /* ����DMA */
    dma_adc1_handle.Instance = ADC1_DMA_STREAM;
    dma_adc1_handle.Init.Request = DMA_REQUEST_ADC1;
    dma_adc1_handle.Init.Direction = DMA_PERIPH_TO_MEMORY;
    dma_adc1_handle.Init.PeriphInc = DMA_PINC_DISABLE;
    dma_adc1_handle.Init.MemInc = DMA_MINC_ENABLE;
    dma_adc1_handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    dma_adc1_handle.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    dma_adc1_handle.Init.Mode = DMA_CIRCULAR;   //DMA_NORMAL;//
    dma_adc1_handle.Init.Priority = DMA_PRIORITY_VERY_HIGH;
    dma_adc1_handle.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    dma_adc1_handle.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_1QUARTERFULL;
    dma_adc1_handle.Init.MemBurst = DMA_MBURST_SINGLE;
    dma_adc1_handle.Init.PeriphBurst = DMA_PBURST_SINGLE;
    HAL_DMA_Init(&dma_adc1_handle);

    dma_adc2_handle.Instance = ADC2_DMA_STREAM;
    dma_adc2_handle.Init.Request = DMA_REQUEST_ADC2;
    dma_adc2_handle.Init.Direction = DMA_PERIPH_TO_MEMORY;
    dma_adc2_handle.Init.PeriphInc = DMA_PINC_DISABLE;
    dma_adc2_handle.Init.MemInc = DMA_MINC_ENABLE;
    dma_adc2_handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    dma_adc2_handle.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    dma_adc2_handle.Init.Mode = DMA_CIRCULAR;   //DMA_NORMAL;//
    dma_adc2_handle.Init.Priority = DMA_PRIORITY_VERY_HIGH;
    dma_adc2_handle.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    dma_adc2_handle.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_1QUARTERFULL;
    dma_adc2_handle.Init.MemBurst = DMA_MBURST_SINGLE;
    dma_adc2_handle.Init.PeriphBurst = DMA_PBURST_SINGLE;
    HAL_DMA_Init(&dma_adc2_handle);
    
    dma_adc3_handle.Instance = ADC3_DMA_STREAM;
    dma_adc3_handle.Init.Request = DMA_REQUEST_ADC3;
    dma_adc3_handle.Init.Direction = DMA_PERIPH_TO_MEMORY;
    dma_adc3_handle.Init.PeriphInc = DMA_PINC_DISABLE;
    dma_adc3_handle.Init.MemInc = DMA_MINC_ENABLE;
    dma_adc3_handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    dma_adc3_handle.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    dma_adc3_handle.Init.Mode = DMA_CIRCULAR;   //DMA_NORMAL;//
    dma_adc3_handle.Init.Priority = DMA_PRIORITY_VERY_HIGH;
    dma_adc3_handle.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    dma_adc3_handle.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_1QUARTERFULL;
    dma_adc3_handle.Init.MemBurst = DMA_MBURST_SINGLE;
    dma_adc3_handle.Init.PeriphBurst = DMA_PBURST_SINGLE;
    HAL_DMA_Init(&dma_adc3_handle);    
    
    __HAL_LINKDMA(&adc1_handle, DMA_Handle, dma_adc1_handle);
    __HAL_LINKDMA(&adc2_handle, DMA_Handle, dma_adc2_handle);
    __HAL_LINKDMA(&adc3_handle, DMA_Handle, dma_adc3_handle);
    
    /* ����ADC */
    adc1_handle.Instance = ADC1;
    adc1_handle.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;                                    /* ʱ��Դ��ʱ��Ԥ��Ƶϵ�� */
    adc1_handle.Init.Resolution = ADC_RESOLUTION_16B;                                          /* �ֱ��� */
    adc1_handle.Init.ScanConvMode = ADC_SCAN_ENABLE;                                           /* ɨ��ת��ģʽ */
    adc1_handle.Init.EOCSelection = ADC_EOC_SINGLE_CONV;                                       /* ת������������Flag */
    adc1_handle.Init.LowPowerAutoWait = DISABLE;                                               /* �Զ��ӳ�ת�� */
    adc1_handle.Init.ContinuousConvMode = ENABLE;                                              /* ����ת��ģʽ */
    adc1_handle.Init.NbrOfConversion = ADC1_DMA_NUM;                                           /* ɨ��ת��ģʽ�µ�Rank���� */
    adc1_handle.Init.DiscontinuousConvMode = DISABLE;                                          /* ɨ��ת��ģʽ�µļ��ת��ģʽ */
    adc1_handle.Init.NbrOfDiscConversion = 1;                                                  /* ���ת��ģʽ��һ��ת����Rank���� */
    adc1_handle.Init.ExternalTrigConv = ADC_SOFTWARE_START;                                    /* ת���ⲿ����Դ */
    adc1_handle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;                     /* ת���ⲿ����Դ����Ч�� */
    adc1_handle.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DMA_CIRCULAR;                /* ת�����ݹ��� */
    adc1_handle.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;                                       /* ת�����������д */
    adc1_handle.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;                                     /* ת���������� */
    adc1_handle.Init.OversamplingMode = DISABLE;                                               /* ������ģʽ */
    adc1_handle.Init.Oversampling.Ratio = 0;                                                   /* �������� */
    adc1_handle.Init.Oversampling.RightBitShift = ADC_RIGHTBITSHIFT_NONE;                      /* ���������� */
    adc1_handle.Init.Oversampling.TriggeredMode = ADC_TRIGGEREDMODE_SINGLE_TRIGGER;            /* ����������ģʽ */
    adc1_handle.Init.Oversampling.OversamplingStopReset = ADC_REGOVERSAMPLING_CONTINUED_MODE;  /* ���������ģʽ */
    HAL_ADC_Init(&adc1_handle);

    adc2_handle.Instance = ADC2;
    adc2_handle.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;                                    /* ʱ��Դ��ʱ��Ԥ��Ƶϵ�� */
    adc2_handle.Init.Resolution = ADC_RESOLUTION_16B;                                          /* �ֱ��� */
    adc2_handle.Init.ScanConvMode = ADC_SCAN_ENABLE;                                           /* ɨ��ת��ģʽ */
    adc2_handle.Init.EOCSelection = ADC_EOC_SINGLE_CONV;                                       /* ת������������Flag */
    adc2_handle.Init.LowPowerAutoWait = DISABLE;                                               /* �Զ��ӳ�ת�� */
    adc2_handle.Init.ContinuousConvMode = ENABLE;                                              /* ����ת��ģʽ */
    adc2_handle.Init.NbrOfConversion = ADC2_DMA_NUM;                                           /* ɨ��ת��ģʽ�µ�Rank���� */
    adc2_handle.Init.DiscontinuousConvMode = DISABLE;                                          /* ɨ��ת��ģʽ�µļ��ת��ģʽ */
    adc2_handle.Init.NbrOfDiscConversion = 1;                                                  /* ���ת��ģʽ��һ��ת����Rank���� */
    adc2_handle.Init.ExternalTrigConv = ADC_SOFTWARE_START;                                    /* ת���ⲿ����Դ */
    adc2_handle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;                     /* ת���ⲿ����Դ����Ч�� */
    adc2_handle.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DMA_CIRCULAR;                /* ת�����ݹ��� */
    adc2_handle.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;                                       /* ת�����������д */
    adc2_handle.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;                                     /* ת���������� */
    adc2_handle.Init.OversamplingMode = DISABLE;                                               /* ������ģʽ */
    adc2_handle.Init.Oversampling.Ratio = 0;                                                   /* �������� */
    adc2_handle.Init.Oversampling.RightBitShift = ADC_RIGHTBITSHIFT_NONE;                      /* ���������� */
    adc2_handle.Init.Oversampling.TriggeredMode = ADC_TRIGGEREDMODE_SINGLE_TRIGGER;            /* ����������ģʽ */
    adc2_handle.Init.Oversampling.OversamplingStopReset = ADC_REGOVERSAMPLING_CONTINUED_MODE;  /* ���������ģʽ */
    HAL_ADC_Init(&adc2_handle);
 
    adc3_handle.Instance = ADC3;
    adc3_handle.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;                                    /* ʱ��Դ��ʱ��Ԥ��Ƶϵ�� */
    adc3_handle.Init.Resolution = ADC_RESOLUTION_16B;                                          /* �ֱ��� */
    adc3_handle.Init.ScanConvMode = ADC_SCAN_ENABLE;                                           /* ɨ��ת��ģʽ */
    adc3_handle.Init.EOCSelection = ADC_EOC_SINGLE_CONV;                                       /* ת������������Flag */
    adc3_handle.Init.LowPowerAutoWait = DISABLE;                                               /* �Զ��ӳ�ת�� */
    adc3_handle.Init.ContinuousConvMode = ENABLE;                                              /* ����ת��ģʽ */
    adc3_handle.Init.NbrOfConversion = ADC3_DMA_NUM;                                            /* ɨ��ת��ģʽ�µ�Rank���� */
    adc3_handle.Init.DiscontinuousConvMode = DISABLE;                                          /* ɨ��ת��ģʽ�µļ��ת��ģʽ */
    adc3_handle.Init.NbrOfDiscConversion = 1;                                                  /* ���ת��ģʽ��һ��ת����Rank���� */
    adc3_handle.Init.ExternalTrigConv = ADC_SOFTWARE_START;                                    /* ת���ⲿ����Դ */
    adc3_handle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;                     /* ת���ⲿ����Դ����Ч�� */
    adc3_handle.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DMA_CIRCULAR;                /* ת�����ݹ��� */
    adc3_handle.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;                                       /* ת�����������д */
    adc3_handle.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;                                     /* ת���������� */
    adc3_handle.Init.OversamplingMode = DISABLE;                                               /* ������ģʽ */
    adc3_handle.Init.Oversampling.Ratio = 0;                                                   /* �������� */
    adc3_handle.Init.Oversampling.RightBitShift = ADC_RIGHTBITSHIFT_NONE;                      /* ���������� */
    adc3_handle.Init.Oversampling.TriggeredMode = ADC_TRIGGEREDMODE_SINGLE_TRIGGER;            /* ����������ģʽ */
    adc3_handle.Init.Oversampling.OversamplingStopReset = ADC_REGOVERSAMPLING_CONTINUED_MODE;  /* ���������ģʽ */
    HAL_ADC_Init(&adc3_handle);
    
    /* ADC�Զ���У׼ */
    HAL_ADCEx_Calibration_Start(&adc1_handle, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED);
    HAL_ADCEx_Calibration_Start(&adc2_handle, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED);
    HAL_ADCEx_Calibration_Start(&adc3_handle, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED);

    HAL_NVIC_SetPriority(DMA1_Stream0_IRQn, 0, 2);
    HAL_NVIC_EnableIRQ(DMA1_Stream0_IRQn); 
    HAL_NVIC_SetPriority(DMA1_Stream1_IRQn, 0, 2);
    HAL_NVIC_EnableIRQ(DMA1_Stream1_IRQn);
    HAL_NVIC_SetPriority(DMA1_Stream2_IRQn, 0, 2);
    HAL_NVIC_EnableIRQ(DMA1_Stream2_IRQn);
}

uint32_t adc1_chx[ADC1_DMA_NUM];
uint32_t adc2_chx[ADC2_DMA_NUM];
uint32_t adc3_chx[ADC3_DMA_NUM];

uint8_t adc1_chx_num=ADC1_DMA_NUM;
uint8_t adc2_chx_num=ADC2_DMA_NUM;
uint8_t adc3_chx_num=ADC3_DMA_NUM;

uint8_t adc_chx_total=0;

uint8_t adc_number[18]={0}; //adc���

uint8_t adc_result_value[60];
uint8_t adc_result_size=0;

uint8_t adc_start_flag=0;

uint8_t adc_sample_cycle=ADC_SAMPLETIME_810CYCLES_5;    //��������

void adc_set_param(uint8_t resolution,uint16_t enable_16c,uint8_t enable_2c,uint8_t cycle)
{
    uint8_t i=0;
    uint8_t j=0;
    uint32_t adc_input_x[16]={ADC_AIN1,ADC_AIN2,ADC_AIN3,ADC_AIN4,ADC_AIN5,ADC_AIN6,ADC_AIN7,ADC_AIN8,ADC_AIN9,ADC_AIN10,ADC_AIN11,ADC_AIN12,ADC_AIN13,ADC_AIN14,ADC_AIN15,ADC_AIN16};
    
    switch(resolution)  //�ֱ���
    {
        case 0x08:
            adc1_handle.Init.Resolution = ADC_RESOLUTION_8B; 
            adc2_handle.Init.Resolution = ADC_RESOLUTION_8B; 
            adc3_handle.Init.Resolution = ADC_RESOLUTION_8B; 
        break;
        
        case 0x0A:
            adc1_handle.Init.Resolution = ADC_RESOLUTION_10B; 
            adc2_handle.Init.Resolution = ADC_RESOLUTION_10B; 
            adc3_handle.Init.Resolution = ADC_RESOLUTION_10B;
        break;
                
        case 0x0C:
            adc1_handle.Init.Resolution = ADC_RESOLUTION_12B; 
            adc2_handle.Init.Resolution = ADC_RESOLUTION_12B; 
            adc3_handle.Init.Resolution = ADC_RESOLUTION_12B;
        break;
                        
        case 0x0E:
            adc1_handle.Init.Resolution = ADC_RESOLUTION_14B; 
            adc2_handle.Init.Resolution = ADC_RESOLUTION_14B; 
            adc3_handle.Init.Resolution = ADC_RESOLUTION_14B;
        break;
                                
        case 0x10:
            adc1_handle.Init.Resolution = ADC_RESOLUTION_16B; 
            adc2_handle.Init.Resolution = ADC_RESOLUTION_16B; 
            adc3_handle.Init.Resolution = ADC_RESOLUTION_16B;
        break;
        
        default:
        break;
    }
 
    adc1_chx_num=0;
    adc2_chx_num=0;
    adc3_chx_num=0;
    for(i=0;i<16;i++)
    {
        if(enable_16c & 0x0001)
        {
            if((i==0)||(i==2)||(i==4))
            {               
                adc1_chx[adc1_chx_num++]=adc_input_x[i];   
				printf("adc1 ch %d= %d\r\n",adc1_chx_num,i);
            }
            else if((i==1)||(i==15))
            {               
                adc2_chx[adc2_chx_num++]=adc_input_x[i];  
				printf("adc2 ch %d= %d\r\n",adc2_chx_num,i);
            }
            else
            {
                printf("adc3 ch %d= %d\r\n",adc3_chx_num,i);
                adc3_chx[adc3_chx_num++]=adc_input_x[i];           
            }
            adc_number[j++]=i;
        }      
        enable_16c=enable_16c>>1;    
    }

    if(enable_2c & 0x01)
    {
        printf("adc1 IN\r\n");
        adc1_chx[adc1_chx_num++]=ADC_AIN1C;
        adc_number[j++]=16;
    }

    if(enable_2c & 0x02)
    {
        printf("adc2 IN\r\n");
        adc2_chx[adc2_chx_num++]=ADC_AIN2C;
        adc_number[j++]=17;
    }
    
    adc_chx_total=adc1_chx_num+adc2_chx_num+adc3_chx_num;
    
    adc1_handle.Init.NbrOfConversion = adc1_chx_num;
    adc2_handle.Init.NbrOfConversion = adc2_chx_num;
    adc3_handle.Init.NbrOfConversion = adc3_chx_num;
    
    printf("adc b%d n %d %d %d\r\n",resolution,adc1_chx_num,adc2_chx_num,adc3_chx_num);
        
    HAL_ADC_Init(&adc1_handle);
    HAL_ADC_Init(&adc2_handle);
    HAL_ADC_Init(&adc3_handle);

    /* ADC�Զ���У׼ */
    HAL_ADCEx_Calibration_Start(&adc1_handle, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED);
    HAL_ADCEx_Calibration_Start(&adc2_handle, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED);
    HAL_ADCEx_Calibration_Start(&adc3_handle, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED);


    switch(cycle)
    {
        case 0:
            adc_sample_cycle=ADC_SAMPLETIME_1CYCLE_5;
        break;
        
        case 1:
            adc_sample_cycle=ADC_SAMPLETIME_2CYCLES_5;
        break;
        
        case 2:
            adc_sample_cycle=ADC_SAMPLETIME_8CYCLES_5;
        break;        
    
        case 3:
            adc_sample_cycle=ADC_SAMPLETIME_16CYCLES_5;
        break;

        case 4:
            adc_sample_cycle=ADC_SAMPLETIME_32CYCLES_5;
        break;

        case 5:
            adc_sample_cycle=ADC_SAMPLETIME_64CYCLES_5;
        break;

        case 6:
            adc_sample_cycle=ADC_SAMPLETIME_387CYCLES_5;
        break;

        case 7:
            adc_sample_cycle=ADC_SAMPLETIME_810CYCLES_5;
        break;

        default:
        break;
    }     
}


/**
 * @brief   ������ͨ��ADC DMA��ȡ
 * @param   
 * @retval  ��
 */
void adc_dma_start(ADC_HandleTypeDef *hadc,__IO uint16_t pData[],uint8_t cycle,uint8_t num,uint32_t ch[])
{
    uint8_t i=0;
    uint32_t rank[11]={ADC_REGULAR_RANK_1,ADC_REGULAR_RANK_2,ADC_REGULAR_RANK_3,ADC_REGULAR_RANK_4,ADC_REGULAR_RANK_5,ADC_REGULAR_RANK_6,ADC_REGULAR_RANK_7,ADC_REGULAR_RANK_8,ADC_REGULAR_RANK_9,ADC_REGULAR_RANK_10,ADC_REGULAR_RANK_11};
    ADC_ChannelConfTypeDef adc_channel_conf_struct = {0};
    
    /* ֹͣADC DMAת�� */
    HAL_ADC_Stop_DMA(hadc);
    
    /* ����ADCͨ�� */
    adc_channel_conf_struct.SamplingTime = cycle;                           /* ����ʱ�� */
    adc_channel_conf_struct.SingleDiff = ADC_SINGLE_ENDED;                  /* ��������ģʽ */
    adc_channel_conf_struct.OffsetNumber = ADC_OFFSET_NONE;                 /* ƫ�� */
    adc_channel_conf_struct.Offset = 0;                                     /* ƫ���� */
    adc_channel_conf_struct.OffsetRightShift = DISABLE;                     /* ƫ�ƺ����� */
    adc_channel_conf_struct.OffsetSignedSaturation = DISABLE;               /* ���ű��� */
   
    for(i=0;i<num;i++)
    {
        adc_channel_conf_struct.Channel = ch[i];           /* ͨ�� */
        adc_channel_conf_struct.Rank = rank[i];            /* Rank��� */
        HAL_ADC_ConfigChannel(hadc, &adc_channel_conf_struct);   
    }

    //ʹ��ADC1
    ADC_Enable(hadc);    
    /* ����ADC DMAת�� */
    HAL_ADC_Start_DMA(hadc, (uint32_t *)pData, num);
    
    HAL_ADC_Start(hadc);
}

void adc_start(void)
{
    if(adc1_chx_num)
    {
        adc_dma_start(&adc1_handle,adc1_dma_buf,adc_sample_cycle,adc1_chx_num,adc1_chx);
    }
    if(adc2_chx_num)
    {
        adc_dma_start(&adc2_handle,adc2_dma_buf,adc_sample_cycle,adc2_chx_num,adc2_chx);
    }
    if(adc3_chx_num)
    {
        adc_dma_start(&adc3_handle,adc3_dma_buf,adc_sample_cycle,adc3_chx_num,adc3_chx);
    }
    
    if(adc_chx_total)
    {
        adc_start_flag=1;
    }
}

void adc_stop(void)
{  
    HAL_ADC_Stop_DMA(&adc1_handle);
    HAL_ADC_Stop_DMA(&adc2_handle);
    HAL_ADC_Stop_DMA(&adc3_handle);
    
    HAL_ADC_Stop(&adc1_handle);
    HAL_ADC_Stop(&adc2_handle);
    HAL_ADC_Stop(&adc3_handle);
    
    adc_start_flag=0;
}

#if 1
/**
 * @brief   ������ͨ��ADC DMA��ȡ
 * @param   length: DMA��ȡ����
 * @retval  ��
 */
void adc1_dma_enable(uint32_t length)
{
    ADC_ChannelConfTypeDef adc_channel_conf_struct = {0};
    
    /* ֹͣADC DMAת�� */
    HAL_ADC_Stop_DMA(&adc1_handle);
    
    /* ����ADCͨ�� */
    adc_channel_conf_struct.Channel = ADC1_A1_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_1;                      /* Rank��� */
    adc_channel_conf_struct.SamplingTime = ADC_SAMPLETIME_810CYCLES_5;      /* ����ʱ�� */
    adc_channel_conf_struct.SingleDiff = ADC_SINGLE_ENDED;                  /* ��������ģʽ */
    adc_channel_conf_struct.OffsetNumber = ADC_OFFSET_NONE;                 /* ƫ�� */
    adc_channel_conf_struct.Offset = 0;                                     /* ƫ���� */
    adc_channel_conf_struct.OffsetRightShift = DISABLE;                     /* ƫ�ƺ����� */
    adc_channel_conf_struct.OffsetSignedSaturation = DISABLE;               /* ���ű��� */
    HAL_ADC_ConfigChannel(&adc1_handle, &adc_channel_conf_struct);
    
    adc_channel_conf_struct.Channel = ADC1_A2_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_2;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc1_handle, &adc_channel_conf_struct);

    adc_channel_conf_struct.Channel = ADC1_A3_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_3;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc1_handle, &adc_channel_conf_struct);

    adc_channel_conf_struct.Channel = ADC1_A4_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_4;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc1_handle, &adc_channel_conf_struct);

    //ʹ��ADC1
    ADC_Enable(&adc1_handle);
    
    /* ����ADC DMAת�� */
    HAL_ADC_Start_DMA(&adc1_handle, (uint32_t *)adc1_dma_buf, length);
    
    HAL_ADC_Start(&adc1_handle);
}

void adc2_dma_enable(uint32_t length)
{
    ADC_ChannelConfTypeDef adc_channel_conf_struct = {0};
    
    /* ֹͣADC DMAת�� */
    HAL_ADC_Stop_DMA(&adc2_handle);
    
    /* ����ADCͨ�� */
    adc_channel_conf_struct.Channel = ADC2_A1_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_1;                      /* Rank��� */
    adc_channel_conf_struct.SamplingTime = ADC_SAMPLETIME_810CYCLES_5;      /* ����ʱ�� */
    adc_channel_conf_struct.SingleDiff = ADC_SINGLE_ENDED;                  /* ��������ģʽ */
    adc_channel_conf_struct.OffsetNumber = ADC_OFFSET_NONE;                 /* ƫ�� */
    adc_channel_conf_struct.Offset = 0;                                     /* ƫ���� */
    adc_channel_conf_struct.OffsetRightShift = DISABLE;                     /* ƫ�ƺ����� */
    adc_channel_conf_struct.OffsetSignedSaturation = DISABLE;               /* ���ű��� */
    HAL_ADC_ConfigChannel(&adc2_handle, &adc_channel_conf_struct);
    
    adc_channel_conf_struct.Channel = ADC2_A2_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_2;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc2_handle, &adc_channel_conf_struct);

    adc_channel_conf_struct.Channel = ADC2_A3_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_3;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc2_handle, &adc_channel_conf_struct);

    //ʹ��ADC1
    ADC_Enable(&adc2_handle);
    
    /* ����ADC DMAת�� */
    HAL_ADC_Start_DMA(&adc2_handle, (uint32_t *)adc2_dma_buf, length);
    
    HAL_ADC_Start(&adc2_handle);
}

void adc3_dma_enable(uint32_t length)
{
    ADC_ChannelConfTypeDef adc_channel_conf_struct = {0};
    
    /* ֹͣADC DMAת�� */
    HAL_ADC_Stop_DMA(&adc3_handle);
    
    /* ����ADCͨ�� */
    adc_channel_conf_struct.Channel = ADC3_A1_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_1;                      /* Rank��� */
    adc_channel_conf_struct.SamplingTime = ADC_SAMPLETIME_810CYCLES_5;      /* ����ʱ�� */
    adc_channel_conf_struct.SingleDiff = ADC_SINGLE_ENDED;                  /* ��������ģʽ */
    adc_channel_conf_struct.OffsetNumber = ADC_OFFSET_NONE;                 /* ƫ�� */
    adc_channel_conf_struct.Offset = 0;                                     /* ƫ���� */
    adc_channel_conf_struct.OffsetRightShift = DISABLE;                     /* ƫ�ƺ����� */
    adc_channel_conf_struct.OffsetSignedSaturation = DISABLE;               /* ���ű��� */
    HAL_ADC_ConfigChannel(&adc3_handle, &adc_channel_conf_struct);
    
    adc_channel_conf_struct.Channel = ADC3_A2_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_2;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc3_handle, &adc_channel_conf_struct);

    adc_channel_conf_struct.Channel = ADC3_A3_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_3;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc3_handle, &adc_channel_conf_struct);

    adc_channel_conf_struct.Channel = ADC3_A4_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_4;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc3_handle, &adc_channel_conf_struct);

    adc_channel_conf_struct.Channel = ADC3_A5_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_5;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc3_handle, &adc_channel_conf_struct);

    adc_channel_conf_struct.Channel = ADC3_A6_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_6;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc3_handle, &adc_channel_conf_struct);

    adc_channel_conf_struct.Channel = ADC3_A7_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_7;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc3_handle, &adc_channel_conf_struct);
    
    adc_channel_conf_struct.Channel = ADC3_A8_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_8;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc3_handle, &adc_channel_conf_struct);

    adc_channel_conf_struct.Channel = ADC3_A9_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_9;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc3_handle, &adc_channel_conf_struct);

    adc_channel_conf_struct.Channel = ADC3_A10_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_10;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc3_handle, &adc_channel_conf_struct);
 
    adc_channel_conf_struct.Channel = ADC3_A11_CH;                           /* ͨ�� */
    adc_channel_conf_struct.Rank = ADC_REGULAR_RANK_11;                      /* Rank��� */
    HAL_ADC_ConfigChannel(&adc3_handle, &adc_channel_conf_struct);
 
    //ʹ��ADC1
    ADC_Enable(&adc3_handle);
    
    /* ����ADC DMAת�� */
    HAL_ADC_Start_DMA(&adc3_handle, (uint32_t *)adc3_dma_buf, length);
    
    HAL_ADC_Start(&adc3_handle);
}
#endif


/**
 * @brief   HAL��ADCת����ɻص�����
 * @param   hadc: ADC���
 * @retval  ��
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
    if (hadc->Instance == ADC1)
    {
        adc1_dma_sta = 1;
    }
    else if (hadc->Instance == ADC2)
    {
        adc2_dma_sta = 1;
    }
    else if (hadc->Instance == ADC3)
    {
        adc3_dma_sta = 1;
    }
}

/**
 * @brief   DMA�жϷ�����
 * @param   ��
 * @retval  ��
 */
void ADC1_DMA_IRQHandler(void)
{
    HAL_DMA_IRQHandler(&dma_adc1_handle);
}

void ADC2_DMA_IRQHandler(void)
{
    HAL_DMA_IRQHandler(&dma_adc2_handle);
}

void ADC3_DMA_IRQHandler(void)
{
    HAL_DMA_IRQHandler(&dma_adc3_handle);
}


uint16_t adc1_result[ADC1_DMA_NUM];
uint16_t adc2_result[ADC2_DMA_NUM];
uint16_t adc3_result[ADC3_DMA_NUM];

void read_adc1_result(void)
{
    uint8_t ch=0;
    uint16_t index;
    uint32_t result_sum;
    
//    if(adc1_dma_sta == 1)
//    {
//        adc1_dma_sta = 0;
//        SCB_InvalidateDCache();
//        
//        for (ch=0; ch<ADC1_DMA_NUM; ch++)
//        {
//            /* ��DMA��ȡ�Ķ��ADC���ݽ��о�ֵ�˲� */
//            for (result_sum = 0, index=0; index<ADC1_RNUM; index++)
//            {
//                result_sum += adc1_dma_buf[(ADC1_DMA_NUM * index) + ch];
//            }
//            adc1_result[ch] = result_sum / ADC1_RNUM;
//            printf("adc1 ch%d = %d\r\n",ch,adc1_result[ch]);
//        }             
//        adc1_dma_enable(ADC1_DMA_BUF_SIZE);
//    }

	adc1_result[0] = adc1_dma_buf[0];
	adc1_result[1] = adc1_dma_buf[1];
	adc1_result[2] = adc1_dma_buf[2];
	adc1_result[3] = adc1_dma_buf[3];

	printf("adc1 ch1 = %d\r\n",adc1_result[0]);
	printf("adc1 ch2 = %d\r\n",adc1_result[1]);
	printf("adc1 ch3 = %d\r\n",adc1_result[2]);
	printf("adc1 ch4 = %d\r\n",adc1_result[3]);
}


void read_adc2_result(void)
{
    uint8_t ch=0;
    uint16_t index;
    uint32_t result_sum;
    
    if(adc2_dma_sta == 1)
    {
        adc2_dma_sta = 0;
        SCB_InvalidateDCache();
        
        for (ch=0; ch<ADC2_DMA_NUM; ch++)
        {
            /* ��DMA��ȡ�Ķ��ADC���ݽ��о�ֵ�˲� */
            for (result_sum = 0, index=0; index<ADC2_RNUM; index++)
            {
                result_sum += adc2_dma_buf[(ADC2_DMA_NUM * index) + ch];
            }
            adc2_result[ch] = result_sum / ADC2_RNUM;
            printf("adc2 ch%d = %d\r\n",ch,adc2_result[ch]);
        }
              
        adc2_dma_enable(ADC2_DMA_BUF_SIZE);
    }
}

void read_adc3_result(void)
{
    uint8_t ch=0;
    uint16_t index;
    uint32_t result_sum;
    
    if(adc3_dma_sta == 1)
    {
        adc3_dma_sta = 0;
        SCB_InvalidateDCache();
        
        for (ch=0; ch<ADC3_DMA_NUM; ch++)
        {
            /* ��DMA��ȡ�Ķ��ADC���ݽ��о�ֵ�˲� */
            for (result_sum = 0, index=0; index<ADC3_RNUM; index++)
            {
                result_sum += adc3_dma_buf[(ADC3_DMA_NUM * index) + ch];
            }
            adc3_result[ch] = result_sum / ADC3_RNUM;
            printf("adc3 ch%d = %d\r\n",ch,adc3_result[ch]);
        }
              
        adc3_dma_enable(ADC3_DMA_BUF_SIZE);
    }
}

void adc_result(void)
{
    uint8_t i=0;
    uint8_t j=0;
    uint8_t a1=0;
    uint8_t a2=0;
    uint8_t a3=0;
//	read_adc1_result();
//	read_adc2_result();
//	read_adc3_result();
    
    if(adc_start_flag)
    {  
        for(i=0;i<adc1_chx_num;i++)
        {   
            adc1_result[i] = adc1_dma_buf[i];
      //      printf("adc1 %d = %d\r\n",i,adc1_result[i]);
        }

        for(i=0;i<adc2_chx_num;i++)
        {   
            adc2_result[i] = adc2_dma_buf[i];
     //       printf("adc2 %d = %d\r\n",i,adc2_result[i]);
        }

        for(i=0;i<adc3_chx_num;i++)
        {   
            adc3_result[i] = adc3_dma_buf[i];
    //        printf("adc3 %d = %d\r\n",i,adc3_result[i]);
        } 

        adc_result_value[j++]=NET_F_HEAD;
        adc_result_value[j++]=adc_chx_total*3;
        adc_result_value[j++]=NET_F_CMD_ADC_RES;
        
        for(i=0;i<adc_chx_total;i++)
        {
            switch(adc_number[i])
            {
                //ADC1
                case 0:
                case 2:
                case 4:
                case 16:
                    adc_result_value[j++]=adc_number[i]+1;
                    adc_result_value[j++]=adc1_result[a1]>>8;
                    adc_result_value[j++]=adc1_result[a1++];
                break;
                
                //ADC2
                case 1:
                case 15:
                case 17:
                    adc_result_value[j++]=adc_number[i]+1;
                    adc_result_value[j++]=adc2_result[a2]>>8; 
                    adc_result_value[j++]=adc2_result[a2++]; 
                break;
                
                //ADC3
                default:
                    adc_result_value[j++]=adc_number[i]+1;
                    adc_result_value[j++]=adc3_result[a3]>>8; 
                    adc_result_value[j++]=adc3_result[a3++];
                break;     
            }   
        }
        adc_result_value[j++]=cal_crc(adc_result_value, 3+adc_result_value[1]);
        adc_result_size=j;
    }
}



#if 0
/**
 * @brief   ��ʼ��ADC������
 * @param   ratio: ����������
 * @param   right_shift: ����������λ��
 * @arg     ADC_RIGHTBITSHIFT_NONE: ������
 * @arg     ADC_RIGHTBITSHIFT_1: ����1λ
 * @arg     ADC_RIGHTBITSHIFT_2: ����2λ
 * @arg     ADC_RIGHTBITSHIFT_3: ����3λ
 * @arg     ADC_RIGHTBITSHIFT_4: ����4λ
 * @arg     ADC_RIGHTBITSHIFT_5: ����5λ
 * @arg     ADC_RIGHTBITSHIFT_6: ����6λ
 * @arg     ADC_RIGHTBITSHIFT_7: ����7λ
 * @arg     ADC_RIGHTBITSHIFT_8: ����8λ
 * @arg     ADC_RIGHTBITSHIFT_9: ����9λ
 * @arg     ADC_RIGHTBITSHIFT_10: ����10λ
 * @arg     ADC_RIGHTBITSHIFT_11: ����11λ
 * @retval  ��
 */
void adc_oversample_init(uint32_t ratio, uint32_t right_shift)
{
    GPIO_InitTypeDef gpio_init_struct = {0};
    
    /* ����ʱ�� */
    rcc_periph_clk_init_struct.PeriphClockSelection |= RCC_PERIPHCLK_ADC;
    rcc_periph_clk_init_struct.AdcClockSelection = RCC_ADCCLKSOURCE_PLL2;
    HAL_RCCEx_PeriphCLKConfig(&rcc_periph_clk_init_struct);
    
    /* ʹ��ʱ�� */
    ADC_OS_ADCX_CLK_ENABLE();
    ADC_OS_ADCX_CHY_GPIO_CLK_ENABLE();
    
    /* ѡ��ʱ��Դ */
    __HAL_RCC_ADC_CONFIG(RCC_ADCCLKSOURCE_CLKP);
    
    /* ����ADC�������� */
    gpio_init_struct.Pin = ADC_OS_ADCX_CHY_GPIO_PIN;
    gpio_init_struct.Mode = GPIO_MODE_ANALOG;
    HAL_GPIO_Init(ADC_OS_ADCX_CHY_GPIO_PORT, &gpio_init_struct);
    
    /* ����ADC */
    g_adc_handle.Instance = ADC_OS_ADCX;
    g_adc_handle.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;                                    /* ʱ��Դ��ʱ��Ԥ��Ƶϵ�� */
    g_adc_handle.Init.Resolution = ADC_RESOLUTION_16B;                                          /* �ֱ��� */
    g_adc_handle.Init.ScanConvMode = ADC_SCAN_DISABLE;                                          /* ɨ��ת��ģʽ */
    g_adc_handle.Init.EOCSelection = ADC_EOC_SINGLE_CONV;                                       /* ת������������Flag */
    g_adc_handle.Init.LowPowerAutoWait = DISABLE;                                               /* �Զ��ӳ�ת�� */
    g_adc_handle.Init.ContinuousConvMode = DISABLE;                                             /* ����ת��ģʽ */
    g_adc_handle.Init.NbrOfConversion = 1;                                                      /* ɨ��ת��ģʽ�µ�Rank���� */
    g_adc_handle.Init.DiscontinuousConvMode = DISABLE;                                          /* ɨ��ת��ģʽ�µļ��ת��ģʽ */
    g_adc_handle.Init.NbrOfDiscConversion = 1;                                                  /* ���ת��ģʽ��һ��ת����Rank���� */
    g_adc_handle.Init.ExternalTrigConv = ADC_SOFTWARE_START;                                    /* ת���ⲿ����Դ */
    g_adc_handle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;                     /* ת���ⲿ����Դ����Ч�� */
    g_adc_handle.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DR;                         /* ת�����ݹ��� */
    g_adc_handle.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;                                       /* ת�����������д */
    g_adc_handle.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;                                     /* ת���������� */
    g_adc_handle.Init.OversamplingMode = ENABLE;                                                /* ������ģʽ */
    g_adc_handle.Init.Oversampling.Ratio = ratio;                                               /* �������� */
    g_adc_handle.Init.Oversampling.RightBitShift = right_shift;                                 /* ���������� */
    g_adc_handle.Init.Oversampling.TriggeredMode = ADC_TRIGGEREDMODE_SINGLE_TRIGGER;            /* ����������ģʽ */
    g_adc_handle.Init.Oversampling.OversamplingStopReset = ADC_REGOVERSAMPLING_CONTINUED_MODE;  /* ���������ģʽ */
    HAL_ADC_Init(&g_adc_handle);
    
    /* ADC�Զ���У׼ */
    HAL_ADCEx_Calibration_Start(&g_adc_handle, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED);
}
#endif
