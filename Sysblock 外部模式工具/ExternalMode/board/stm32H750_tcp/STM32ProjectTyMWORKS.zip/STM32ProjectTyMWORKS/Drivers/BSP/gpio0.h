#ifndef _GPIO_H
#define _GPIO_H

#include "./SYSTEM/sys/sys.h"

#define DI1_Pin 			GPIO_PIN_4
#define DI1_GPIO_Port 		GPIOI
#define DI2_Pin 			GPIO_PIN_4
#define DI2_GPIO_Port 		GPIOB
#define DI3_Pin 			GPIO_PIN_7
#define DI3_GPIO_Port 		GPIOB
#define DI4_Pin 			GPIO_PIN_14
#define DI4_GPIO_Port 		GPIOC
#define DI5_Pin 			GPIO_PIN_15
#define DI5_GPIO_Port 		GPIOC
#define DI6_Pin 			GPIO_PIN_4
#define DI6_GPIO_Port 		GPIOE
#define DI7_Pin 			GPIO_PIN_5
#define DI7_GPIO_Port 		GPIOE
#define DI8_Pin 			GPIO_PIN_9
#define DI8_GPIO_Port 		GPIOI

#define DO1_Pin 			GPIO_PIN_1
#define DO1_GPIO_Port 		GPIOI
#define DO2_Pin 			GPIO_PIN_15
#define DO2_GPIO_Port 		GPIOA
#define DO3_Pin 			GPIO_PIN_3
#define DO3_GPIO_Port 		GPIOD
#define DO4_Pin 			GPIO_PIN_4
#define DO4_GPIO_Port 		GPIOD
#define DO5_Pin 			GPIO_PIN_9
#define DO5_GPIO_Port 		GPIOG
#define DO6_Pin 			GPIO_PIN_12
#define DO6_GPIO_Port 		GPIOG
#define DO7_Pin 			GPIO_PIN_10
#define DO7_GPIO_Port 		GPIOG
#define DO8_Pin 			GPIO_PIN_5
#define DO8_GPIO_Port 		GPIOB

#define LED_Pin 			GPIO_PIN_8
#define LED_GPIO_Port 		GPIOI

#define ENC_C_Pin 			GPIO_PIN_11
#define ENC_C_GPIO_Port 	GPIOA
#define ENC_B_Pin 			GPIO_PIN_7
#define ENC_B_GPIO_Port 	GPIOC
#define ENC_A_Pin 			GPIO_PIN_6
#define ENC_A_GPIO_Port 	GPIOC
#define ABC_R_Pin 			GPIO_PIN_11
#define ABC_R_GPIO_Port 	GPIOB

#define RELAY_K1_Pin 		GPIO_PIN_7
#define RELAY_K1_GPIO_Port 	GPIOG
#define RELAY_K2_Pin 		GPIO_PIN_6
#define RELAY_K2_GPIO_Port 	GPIOG

#define LCD_CS_Pin 			GPIO_PIN_10
#define LCD_CS_GPIO_Port 	GPIOH

#define LCD_SDA_Pin 		GPIO_PIN_9
#define LCD_SDA_GPIO_Port 	GPIOH
#define LCD_SCL_Pin 		GPIO_PIN_12
#define LCD_SCL_GPIO_Port 	GPIOH
#define LCD_RST_Pin 		GPIO_PIN_8
#define LCD_RST_GPIO_Port 	GPIOH
#define LCD_SCK_Pin 		GPIO_PIN_12
#define LCD_SCK_GPIO_Port 	GPIOB
#define LCD_PEN_Pin 		GPIO_PIN_7
#define LCD_PEN_GPIO_Port 	GPIOH

/* IO���� */
#define LED(x)    			do { (x) ?                                                  \
							HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET):    \
							HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);  \
                            } while (0)

#define LED_TOGGLE()       	do { HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin); } while (0)

#define RELAY_K1(x)    		do { (x) ?                                                  \
							HAL_GPIO_WritePin(RELAY_K1_GPIO_Port, RELAY_K1_Pin, GPIO_PIN_SET):    \
							HAL_GPIO_WritePin(RELAY_K1_GPIO_Port, RELAY_K1_Pin, GPIO_PIN_RESET);  \
                            } while (0)

#define RELAY_K2(x)    		do { (x) ?                                                  \
							HAL_GPIO_WritePin(RELAY_K2_GPIO_Port, RELAY_K2_Pin, GPIO_PIN_SET):    \
							HAL_GPIO_WritePin(RELAY_K2_GPIO_Port, RELAY_K2_Pin, GPIO_PIN_RESET);  \
                            } while (0)

#define DO1(x)    			do { (x) ?                                                  \
							HAL_GPIO_WritePin(DO1_GPIO_Port, DO1_Pin, GPIO_PIN_SET):    \
							HAL_GPIO_WritePin(DO1_GPIO_Port, DO1_Pin, GPIO_PIN_RESET);  \
                            } while (0)

#define DO2(x)    			do { (x) ?                                                  \
							HAL_GPIO_WritePin(DO2_GPIO_Port, DO2_Pin, GPIO_PIN_SET):    \
							HAL_GPIO_WritePin(DO2_GPIO_Port, DO2_Pin, GPIO_PIN_RESET);  \
                            } while (0)							

#define DO3(x)    			do { (x) ?                                                  \
							HAL_GPIO_WritePin(DO3_GPIO_Port, DO3_Pin, GPIO_PIN_SET):    \
							HAL_GPIO_WritePin(DO3_GPIO_Port, DO3_Pin, GPIO_PIN_RESET);  \
                            } while (0)							

#define DO4(x)    			do { (x) ?                                                  \
							HAL_GPIO_WritePin(DO4_GPIO_Port, DO4_Pin, GPIO_PIN_SET):    \
							HAL_GPIO_WritePin(DO4_GPIO_Port, DO4_Pin, GPIO_PIN_RESET);  \
                            } while (0)							

#define DO5(x)    			do { (x) ?                                                  \
							HAL_GPIO_WritePin(DO5_GPIO_Port, DO5_Pin, GPIO_PIN_SET):    \
							HAL_GPIO_WritePin(DO5_GPIO_Port, DO5_Pin, GPIO_PIN_RESET);  \
                            } while (0)							

#define DO6(x)    			do { (x) ?                                                  \
							HAL_GPIO_WritePin(DO6_GPIO_Port, DO6_Pin, GPIO_PIN_SET):    \
							HAL_GPIO_WritePin(DO6_GPIO_Port, DO6_Pin, GPIO_PIN_RESET);  \
                            } while (0)

#define DO7(x)    			do { (x) ?                                                  \
							HAL_GPIO_WritePin(DO7_GPIO_Port, DO7_Pin, GPIO_PIN_SET):    \
							HAL_GPIO_WritePin(DO7_GPIO_Port, DO7_Pin, GPIO_PIN_RESET);  \
                            } while (0)

#define DO8(x)    			do { (x) ?                                                  \
							HAL_GPIO_WritePin(DO8_GPIO_Port, DO8_Pin, GPIO_PIN_SET):    \
							HAL_GPIO_WritePin(DO8_GPIO_Port, DO8_Pin, GPIO_PIN_RESET);  \
                            } while (0)							

#define DI1		((HAL_GPIO_ReadPin(DI1_GPIO_Port, DI1_Pin) == GPIO_PIN_RESET) ? 0 : 1)
#define DI2		((HAL_GPIO_ReadPin(DI2_GPIO_Port, DI2_Pin) == GPIO_PIN_RESET) ? 0 : 1)
#define DI3		((HAL_GPIO_ReadPin(DI3_GPIO_Port, DI3_Pin) == GPIO_PIN_RESET) ? 0 : 1)
#define DI4		((HAL_GPIO_ReadPin(DI4_GPIO_Port, DI4_Pin) == GPIO_PIN_RESET) ? 0 : 1)
#define DI5		((HAL_GPIO_ReadPin(DI5_GPIO_Port, DI5_Pin) == GPIO_PIN_RESET) ? 0 : 1)
#define DI6		((HAL_GPIO_ReadPin(DI6_GPIO_Port, DI6_Pin) == GPIO_PIN_RESET) ? 0 : 1)
#define DI7		((HAL_GPIO_ReadPin(DI7_GPIO_Port, DI7_Pin) == GPIO_PIN_RESET) ? 0 : 1)
#define DI8		((HAL_GPIO_ReadPin(DI8_GPIO_Port, DI8_Pin) == GPIO_PIN_RESET) ? 0 : 1)
						
#define ENC_A   ((HAL_GPIO_ReadPin(ENC_A_GPIO_Port, ENC_A_Pin) == GPIO_PIN_RESET) ? 0 : 1)
#define ENC_B   ((HAL_GPIO_ReadPin(ENC_B_GPIO_Port, ENC_B_Pin) == GPIO_PIN_RESET) ? 0 : 1)
#define ENC_C   ((HAL_GPIO_ReadPin(ENC_C_GPIO_Port, ENC_C_Pin) == GPIO_PIN_RESET) ? 0 : 1)                            
#define ABC_R   ((HAL_GPIO_ReadPin(ABC_R_GPIO_Port, ABC_R_Pin) == GPIO_PIN_RESET) ? 0 : 1)                            
                            
							
void gpio_init(void);
void dout_set(uint8_t dio_out);
void ENC_test(void);


#endif 
                            

