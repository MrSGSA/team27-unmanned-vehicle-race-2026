#include "gpio.h"
#include "./SYSTEM/usart/usart.h"

//void gpio_init(void)
void gpio_init(GPIO_TypeDef * GPIO_Value,unsigned int GPIO_PIN_Value,unsigned char PIN_Value)
{
		GPIO_InitTypeDef GPIO_InitStruct = {0};

		/* GPIO Ports Clock Enable */
		__HAL_RCC_GPIOI_CLK_ENABLE();
		__HAL_RCC_GPIOB_CLK_ENABLE();
		__HAL_RCC_GPIOK_CLK_ENABLE();
		__HAL_RCC_GPIOG_CLK_ENABLE();
		__HAL_RCC_GPIOD_CLK_ENABLE();
		__HAL_RCC_GPIOC_CLK_ENABLE();
		__HAL_RCC_GPIOA_CLK_ENABLE();
		__HAL_RCC_GPIOJ_CLK_ENABLE();
		__HAL_RCC_GPIOH_CLK_ENABLE();
		__HAL_RCC_GPIOE_CLK_ENABLE();
		__HAL_RCC_GPIOF_CLK_ENABLE();

		/*Configure GPIO pin Output Level */
		HAL_GPIO_WritePin(GPIO_Value, GPIO_PIN_Value, PIN_Value);

		HAL_GPIO_WritePin(RY_CTL_GPIO_Port, RY_CTL_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(BR_CTL_GPIO_Port, BR_CTL_Pin, GPIO_PIN_SET);
		
		/*Configure GPIO pin : PE5 */
		GPIO_InitStruct.Pin = GPIO_PIN_2;
		GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
		HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
		
		/* EXTI interrupt init*/
		HAL_NVIC_SetPriority(EXTI2_IRQn, 0, 0);  // �滻EXTI9_5_IRQnΪEXTI2_IRQn
		HAL_NVIC_EnableIRQ(EXTI2_IRQn); 
	
		/*Configure GPIO pin : PtPin */
		GPIO_InitStruct.Pin = GPIO_PIN_Value;
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Pull = GPIO_PULLUP;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
		HAL_GPIO_Init(GPIO_Value, &GPIO_InitStruct);
		
	GPIO_InitStruct.Pin = RY_CTL_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(RY_CTL_GPIO_Port, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = BR_CTL_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(BR_CTL_GPIO_Port, &GPIO_InitStruct);
 
    GPIO_InitStruct.Pin = ENC_C_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		HAL_GPIO_Init(GPIOG, &GPIO_InitStruct); 
		
		/* EXTI interrupt init*/
		HAL_NVIC_SetPriority(EXTI3_IRQn, 0, 0);  
		HAL_NVIC_EnableIRQ(EXTI3_IRQn);   
}

void gpio_init1(GPIO_TypeDef * GPIO_Value,unsigned int GPIO_PIN_Value)
{
		GPIO_InitTypeDef GPIO_InitStruct = {0};

		/* GPIO Ports Clock Enable */
		__HAL_RCC_GPIOI_CLK_ENABLE();
		__HAL_RCC_GPIOB_CLK_ENABLE();
		__HAL_RCC_GPIOK_CLK_ENABLE();
		__HAL_RCC_GPIOG_CLK_ENABLE();
		__HAL_RCC_GPIOD_CLK_ENABLE();
		__HAL_RCC_GPIOC_CLK_ENABLE();
		__HAL_RCC_GPIOA_CLK_ENABLE();
		__HAL_RCC_GPIOJ_CLK_ENABLE();
		__HAL_RCC_GPIOH_CLK_ENABLE();
		__HAL_RCC_GPIOE_CLK_ENABLE();
		__HAL_RCC_GPIOF_CLK_ENABLE();

		/*Configure GPIO pins : PIPin PIPin */
		GPIO_InitStruct.Pin = GPIO_PIN_Value;
		GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		HAL_GPIO_Init(GPIO_Value, &GPIO_InitStruct);
}

uint8_t dio_in=0;   
uint8_t din_flag=0;

void din_read(void)
{
//    dio_in = DI1 | (DI2<<1) | (DI3<<2) | (DI4<<3) | (DI5<<4) | (DI6<<5) | (DI7<<6) | (DI8<<7);
}

void dout_set(uint8_t dio_out)
{
//    DO1(dio_out&0x01);
//    DO2((dio_out>>1)&0x01);
//    DO3((dio_out>>2)&0x01);
//    DO4((dio_out>>3)&0x01);
//    DO5((dio_out>>4)&0x01);
//    DO6((dio_out>>5)&0x01);
//    DO7((dio_out>>6)&0x01);
//    DO8((dio_out>>7)&0x01);
}

void ENC_test(void)
{
//    static uint8_t flaga=0;
//    static uint8_t flagb=0;
//    static uint8_t flagc=0;
//    static uint8_t flagr=0;
/*
    if((ENC_A==1)&&(flaga==1))
    {
        flaga=0;
        printf("ENC A1\r\n");
    }
    else if((ENC_A==0)&&(flaga==0))
    {
        flaga=1;     
        printf("ENC A0\r\n");
    }

    if((ENC_B==1)&&(flagb==1))
    {
        flagb=0;
        printf("ENC B1\r\n");
    }
    else if((ENC_B==0)&&(flagb==0))
    {
        flagb=1;     
        printf("ENC B0\r\n");
    }
//*/    
//    if((ENC_C==1)&&(flagc==1))
//    {
//        flagc=0;
//        printf("ENC C1\r\n");
//    }
//    else if((ENC_C==0)&&(flagc==0))
//    {
//        flagc=1;     
//        printf("ENC C0\r\n");
//    }

//    if((ABC_R==1)&&(flagr==1))
//    {
//        flagr=0;
//        printf("ABC_R1\r\n");
//    }
//    else if((ABC_R==0)&&(flagr==0))
//    {
//        flagr=1;     
//        printf("ABC_R0\r\n");
//    }    
    
    
}
