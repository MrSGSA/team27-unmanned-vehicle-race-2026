#include "gpio.h"
#include "./SYSTEM/usart/usart.h"

void gpio_init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOI_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOK_CLK_ENABLE();
	__HAL_RCC_GPIOG_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOJ_CLK_ENABLE();
	__HAL_RCC_GPIOH_CLK_ENABLE();
	__HAL_RCC_GPIOE_CLK_ENABLE();
	__HAL_RCC_GPIOF_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(DO8_GPIO_Port, DO8_Pin, GPIO_PIN_SET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOG, DO7_Pin|DO5_Pin|DO6_Pin, GPIO_PIN_SET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOD, DO4_Pin|DO3_Pin, GPIO_PIN_SET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(DO2_GPIO_Port, DO2_Pin, GPIO_PIN_SET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(DO1_GPIO_Port, DO1_Pin, GPIO_PIN_SET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOI, LED_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOG, RELAY_K1_Pin|RELAY_K2_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOH, LCD_CS_Pin|LCD_SDA_Pin|LCD_SCL_Pin|LCD_RST_Pin|LCD_PEN_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(LCD_SCK_GPIO_Port, LCD_SCK_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pins : PIPin PIPin */
	GPIO_InitStruct.Pin = DI1_Pin|DI8_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOI, &GPIO_InitStruct);

	/*Configure GPIO pins : PBPin PBPin PBPin */
	GPIO_InitStruct.Pin = DI2_Pin|DI3_Pin|ABC_R_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/*Configure GPIO pins : PCPin PCPin */
	GPIO_InitStruct.Pin = DI5_Pin|DI4_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	/*Configure GPIO pins : PEPin PEPin */
	GPIO_InitStruct.Pin = DI7_Pin|DI6_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);
	
	
	/*Configure GPIO pin : PtPin */
	GPIO_InitStruct.Pin = DO8_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(DO8_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pins : PGPin PGPin PGPin */
	GPIO_InitStruct.Pin = DO7_Pin|DO5_Pin|DO6_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

	/*Configure GPIO pins : PDPin PDPin */
	GPIO_InitStruct.Pin = DO4_Pin|DO3_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

	/*Configure GPIO pin : PtPin */
	GPIO_InitStruct.Pin = DO2_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(DO2_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pin : PtPin */
	GPIO_InitStruct.Pin = DO1_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(DO1_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pins : PIPin PIPin */
	GPIO_InitStruct.Pin = LED_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);
	
	/*Configure GPIO pins : PGPin PGPin */
	GPIO_InitStruct.Pin = RELAY_K1_Pin|RELAY_K2_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);
	
//	GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_14;
//	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//	GPIO_InitStruct.Pull = GPIO_NOPULL;
//	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
//	GPIO_InitStruct.Alternate = GPIO_AF0_SWJ;
//	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);


//	/*Configure GPIO pins : PE0 PE10 PE9 PE11 PE12 PE15 PE8 PE13 PE7 PE14 */
//	GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_10|GPIO_PIN_9|GPIO_PIN_11
//						  |GPIO_PIN_12|GPIO_PIN_15|GPIO_PIN_8|GPIO_PIN_13
//						  |GPIO_PIN_7|GPIO_PIN_14;
//	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//	GPIO_InitStruct.Pull = GPIO_NOPULL;
//	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//	GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
//	HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

//	/*Configure GPIO pins : PG15 PG8 PG5 PG4 PG2 PG0 PG1 */
//	GPIO_InitStruct.Pin = GPIO_PIN_15|GPIO_PIN_8|GPIO_PIN_5|GPIO_PIN_4
//						  |GPIO_PIN_2|GPIO_PIN_0|GPIO_PIN_1;
//	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//	GPIO_InitStruct.Pull = GPIO_NOPULL;
//	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//	GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
//	HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

//	/*Configure GPIO pins : PD0 PD1 PD15 PD14 PD10 PD9 PD8 */
//	GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_15|GPIO_PIN_14
//						  |GPIO_PIN_10|GPIO_PIN_9|GPIO_PIN_8;
//	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//	GPIO_InitStruct.Pull = GPIO_NOPULL;
//	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//	GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
//	HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

//	/*Configure GPIO pins : PF1 PF0 PF3 PF5 PF4 PF13 PF14 PF12 PF15 PF11 */
//	GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_0|GPIO_PIN_3|GPIO_PIN_5
//						  |GPIO_PIN_4|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_12
//						  |GPIO_PIN_15|GPIO_PIN_11;
//	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//	GPIO_InitStruct.Pull = GPIO_NOPULL;
//	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//	GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
//	HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

//	/*Configure GPIO pins : PC2 PC3 */
//	GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3;
//	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//	GPIO_InitStruct.Pull = GPIO_NOPULL;
//	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//	GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
//	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

//	/*Configure GPIO pin : PH5 */
//	GPIO_InitStruct.Pin = GPIO_PIN_5;
//	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//	GPIO_InitStruct.Pull = GPIO_NOPULL;
//	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//	GPIO_InitStruct.Alternate = GPIO_AF12_FMC;
//	HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);

	/*Configure GPIO pins : PHPin PHPin PHPin PHPin PHPin */
	GPIO_InitStruct.Pin = LCD_CS_Pin|LCD_SDA_Pin|LCD_SCL_Pin|LCD_RST_Pin|LCD_PEN_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);

	/*Configure GPIO pin : PtPin */
	GPIO_InitStruct.Pin = LCD_SCK_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(LCD_SCK_GPIO_Port, &GPIO_InitStruct);
    
    
//  GPIO_InitStruct.Pin = ENC_A_Pin|ENC_B_Pin;
//	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
//	GPIO_InitStruct.Pull = GPIO_NOPULL;
//	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
 
    GPIO_InitStruct.Pin = ENC_C_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct); 
}

uint8_t dio_in=0;   


void dio_in_out(void)
{
    dio_in = DI1 | (DI2<<1) | (DI3<<2) | (DI4<<3) | (DI5<<4) | (DI6<<5) | (DI7<<6) | (DI8<<7);

}

void dout_set(uint8_t dio_out)
{
    DO1(dio_out&0x01);
    DO2((dio_out>>1)&0x01);
    DO3((dio_out>>2)&0x01);
    DO4((dio_out>>3)&0x01);
    DO5((dio_out>>4)&0x01);
    DO6((dio_out>>5)&0x01);
    DO7((dio_out>>6)&0x01);
    DO8((dio_out>>7)&0x01);
}

void ENC_test(void)
{
    static uint8_t flaga=0;
    static uint8_t flagb=0;
    static uint8_t flagc=0;
    static uint8_t flagr=0;
/*
    if((ENC_A==1)&&(flaga==1))
    {
        flaga=0;
        printf("ENC A1\r\n");
    }
    else if((ENC_A==0)&&(flaga==0))
    {
        flaga=1;     
        printf("ENC A0\r\n");
    }

    if((ENC_B==1)&&(flagb==1))
    {
        flagb=0;
        printf("ENC B1\r\n");
    }
    else if((ENC_B==0)&&(flagb==0))
    {
        flagb=1;     
        printf("ENC B0\r\n");
    }
*/    
    if((ENC_C==1)&&(flagc==1))
    {
        flagc=0;
        printf("ENC C1\r\n");
    }
    else if((ENC_C==0)&&(flagc==0))
    {
        flagc=1;     
        printf("ENC C0\r\n");
    }

    if((ABC_R==1)&&(flagr==1))
    {
        flagr=0;
        printf("ABC_R1\r\n");
    }
    else if((ABC_R==0)&&(flagr==0))
    {
        flagr=1;     
        printf("ABC_R0\r\n");
    }    
    
    
}






