#ifndef _USART_H
#define _USART_H

#include "stdio.h"
#include "./SYSTEM/sys/sys.h"

/************************************���Դ���***********************************************************/
#define DEBUG_TX_GPIO_PORT              GPIOC
#define DEBUG_TX_GPIO_PIN               GPIO_PIN_12
#define DEBUG_TX_GPIO_AF                GPIO_AF8_UART5
#define DEBUG_TX_GPIO_CLK_ENABLE()      do{ __HAL_RCC_GPIOC_CLK_ENABLE(); }while(0)   /* ��������ʱ��ʹ�� */

#define DEBUG_RX_GPIO_PORT              GPIOD
#define DEBUG_RX_GPIO_PIN               GPIO_PIN_2
#define DEBUG_RX_GPIO_AF                GPIO_AF8_UART5
#define DEBUG_RX_GPIO_CLK_ENABLE()      do{ __HAL_RCC_GPIOD_CLK_ENABLE(); }while(0)   /* ��������ʱ��ʹ�� */

#define DEBUG_UART                      UART5
#define DEBUG_UART_IRQn                 UART5_IRQn
#define DEBUG_UART_IRQHandler           UART5_IRQHandler
#define DEBUG_UART_CLK_ENABLE()         do{ __HAL_RCC_UART5_CLK_ENABLE(); }while(0)  /* ʱ��ʹ�� */

/************************************RS232����***********************************************************/
#define RS232_TX_GPIO_PORT              GPIOC
#define RS232_TX_GPIO_PIN               GPIO_PIN_10
#define RS232_TX_GPIO_AF                GPIO_AF7_USART3
#define RS232_GPIO_CLK_ENABLE()      	do{ __HAL_RCC_GPIOC_CLK_ENABLE(); }while(0)   /* ��������ʱ��ʹ�� */

#define RS232_RX_GPIO_PORT              GPIOC
#define RS232_RX_GPIO_PIN               GPIO_PIN_11
#define RS232_RX_GPIO_AF                GPIO_AF7_USART3

#define RS232_UART                      USART3
#define RS232_UART_IRQn                 USART3_IRQn
#define RS232_UART_IRQHandler           USART3_IRQHandler
#define RS232_UART_CLK_ENABLE()         do{ __HAL_RCC_USART3_CLK_ENABLE(); }while(0)  /* ʱ��ʹ�� */

/************************************RS485����***********************************************************/
#define RS485_TX_GPIO_PORT              GPIOD
#define RS485_TX_GPIO_PIN               GPIO_PIN_5
#define RS485_TX_GPIO_AF                GPIO_AF7_USART2
#define RS485_GPIO_CLK_ENABLE()      	do{ __HAL_RCC_GPIOD_CLK_ENABLE(); }while(0)   /* ��������ʱ��ʹ�� */

#define RS485_RX_GPIO_PORT              GPIOD
#define RS485_RX_GPIO_PIN               GPIO_PIN_6
#define RS485_RX_GPIO_AF                GPIO_AF7_USART2

#define RS485_EN_GPIO_PORT 				GPIOI
#define RS485_EN_GPIO_PIN 				GPIO_PIN_10
#define RS485_EN_GPIO_CLK_ENABLE()      do{ __HAL_RCC_GPIOI_CLK_ENABLE(); }while(0)   /* ��������ʱ��ʹ�� */

#define RS485_UART                     	USART2
#define RS485_UART_IRQn                 USART2_IRQn
#define RS485_UART_IRQHandler           USART2_IRQHandler
#define RS485_UART_CLK_ENABLE()         do{ __HAL_RCC_USART2_CLK_ENABLE(); }while(0)  /* ʱ��ʹ�� */

#define RS485_TX_EN						HAL_GPIO_WritePin(RS485_EN_GPIO_PORT, RS485_EN_GPIO_PIN, GPIO_PIN_SET);
#define RS485_RX_EN						HAL_GPIO_WritePin(RS485_EN_GPIO_PORT, RS485_EN_GPIO_PIN, GPIO_PIN_RESET);
/*******************************************************************************************************/

#define RS232_RX_MAX   200        /* �����������ֽ��� 200 */
#define RS485_RX_MAX   200        /* �����������ֽ��� 200 */

extern UART_HandleTypeDef debug_uart;    /* UART��� */
extern UART_HandleTypeDef rs232_uart;
extern UART_HandleTypeDef rs485_uart;

extern uint8_t rs232_rxbuf[RS232_RX_MAX]; 
extern uint8_t rs485_rxbuf[RS485_RX_MAX];


void uart_init(void);             /* ���ڳ�ʼ������ */
void dma_init(void);

#endif






